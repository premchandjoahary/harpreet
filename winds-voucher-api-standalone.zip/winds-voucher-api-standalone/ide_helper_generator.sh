#!/bin/bash

php artisan ide-helper:generate

php artisan ide-helper:meta
