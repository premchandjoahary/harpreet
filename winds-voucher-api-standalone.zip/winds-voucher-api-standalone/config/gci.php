<?php

$sandboxMode = env('GCI_SANDBOX_MODE', false);

return [

    'sandbox_mode' => $sandboxMode,

    'credentials' => [
        'id' => $sandboxMode ? env('TEST_GCI_ID') : env('GCI_ID'),
        'key' => $sandboxMode ? env('TEST_GCI_KEY') : env('GCI_KEY'),
    ],

    'api_base_url' => $sandboxMode
        ? env('GCI_SANDBOX_API_BASE_URL', 'http://sandbox.api.giftcardsindia.in')
        : env('GCI_API_BASE_URL', 'http://api.giftcardsindia.in'),

    'api_endpoints' => [
        'access_token' => 'access-token/get',
        'brands' => 'channel/brands',
        'denominations' => 'brand/denominations',
        'order' => [
            'add' => 'order/add',
            'get' => 'order/get',
            'acknowledgement' => 'order/acknowledgement'
        ],
        'card_balance' => 'balance/card',
        'partner_balance' => 'balance/partner',
    ],

];
