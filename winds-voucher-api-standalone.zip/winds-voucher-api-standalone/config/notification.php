<?php

return [

    'seeder_alert_emails' => array_filter(explode(',', env('SEEDER_NOTIFICATION_EMAILS', 'ops@winds.co.in'))),

];
