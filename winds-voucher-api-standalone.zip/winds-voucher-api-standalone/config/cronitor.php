<?php

return [

    'base_url' => env('CRONITOR_BASE_URL', 'https://cronitor.link'),

    'voucher_brand_seeder_key' => env('CRONITOR_VOUCHER_BRAND_SEEDER_KEY'),

    'voucher_denomination_seeder_key' => env('CRONITOR_VOUCHER_DENOMINATION_SEEDER_KEY'),

    'voucher_track_code_generation_key' => env('CRONITOR_VOUCHER_TRACK_CODE_GENERATION_KEY'),

];
