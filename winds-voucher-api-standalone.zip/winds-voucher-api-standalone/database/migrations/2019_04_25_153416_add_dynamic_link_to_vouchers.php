<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddDynamicLinkToVouchers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('vouchers', function (Blueprint $table) {
            $table->string('social_meta_title')->nullable()->after('view_count')->comment('Title for dynamic link');
            $table->string('social_meta_description', 300)->nullable()->after('social_meta_title')->comment('Description for dynamic link');
            $table->string('dynamic_link')->nullable()->after('social_meta_description');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('vouchers', function (Blueprint $table) {
            $table->dropColumn('dynamic_link');
            $table->dropColumn('social_meta_description');
            $table->dropColumn('social_meta_title');
        });
    }
}
