<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDenominationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('denominations', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('voucher_id');
            $table->unsignedInteger('provider_id')->comment('The voucher denomination id of the service provider');
            $table->decimal('value')->comment('The voucher gift card value');
            $table->string('sku_id');
            $table->string('value_type')->comment('The service provider voucher value type');
            $table->string('delivery_type')->index()->comment('The voucher code delivery method');
            $table->boolean('active')->default(true)->comment('Is the voucher denomination enabled by Winds admin');
            $table->boolean('enabled_by_provider')->comment('Is the voucher enabled by the provider');
            $table->timestamps();

            $table->foreign('voucher_id')
                ->references('id')
                ->on('vouchers')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('denominations');
    }
}
