<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->increments('id');
            $table->string('transaction_id');
            $table->unsignedTinyInteger('status')->index();

            $table->unsignedInteger('user_id')->index();
            $table->unsignedInteger('voucher_id');
            $table->unsignedInteger('denomination_id');
            $table->unsignedTinyInteger('quantity');
            $table->decimal('denomination_value')->comment('Single denomination item value');
            $table->timestamp('paid_at')->nullable();

            $table->decimal('total_amount', 10)->comment('The total amount for the vouchers before additional fee and taxes');
            $table->decimal('pg_amount', 10)->default(0)->comment('The payment gateway charges charged by WINDS if any');
            $table->decimal('convenience_fee', 10)->default(0)->comment('The convenience fee charged by WINDS if any');
            $table->decimal('cgst_rate', 4)->default(0)->comment('The gst charged by WINDS if any');
            $table->decimal('cgst_amount', 10)->default(0);
            $table->decimal('sgst_rate', 4)->default(0)->comment('The gst charged by WINDS if any');
            $table->decimal('sgst_amount', 10)->default(0);
            $table->decimal('net_payable_amount', 10)->comment('The final payment amount for the user including fees and taxes');

            $table->unsignedInteger('billing_address_id');
            $table->unsignedInteger('shipping_address_id')->nullable();

            $table->decimal('offer_percentage', 4)->comment('The discount provided by the service provider for WINDS');
            $table->string('delivery_type')->comment('The voucher code delivery method');

            $table->ipAddress('ip')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('voucher_id')
                ->references('id')
                ->on('vouchers')
                ->onDelete('restrict');

            $table->foreign('denomination_id')
                ->references('id')
                ->on('denominations')
                ->onDelete('restrict');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
