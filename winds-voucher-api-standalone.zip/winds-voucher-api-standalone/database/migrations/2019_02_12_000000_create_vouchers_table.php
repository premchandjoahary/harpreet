<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateVouchersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vouchers', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name', 100);
            $table->string('hash', 32)->unique();
            $table->boolean('active')->default(false)->comment('Is the voucher enabled by Winds admin');
            $table->string('delivery_type')->index()->comment('The voucher code delivery method');
            $table->string('discount_type')->comment('The discount type by service provider to us');
            $table->boolean('enabled_by_provider')->comment('Is the voucher enabled by the provider');
            $table->boolean('online')->comment('Can the voucher be redeemed online');
            $table->decimal('offer_percentage', 4)->comment('The discount provided by the service provider for WINDS');
            $table->unsignedSmallInteger('turn_around_time')->comment('Turn around time in hours');
            $table->string('provider_image_url', 2083)->nullable()->comment('The default image url provided by the service provider');
            $table->string('uploaded_image_path')->nullable()->comment('The path of the manually uploaded voucher image file');
            $table->string('website')->nullable();
            $table->text('description')->nullable();
            $table->text('terms')->nullable();
            $table->unsignedInteger('sort_order')->nullable()->comment('The custom order set by admin in which the vouchers should display');
            $table->unsignedBigInteger('view_count')->default(0)->comment('The total view count of the voucher');
            $table->timestamp('last_seeded_at')->nullable();
            $table->timestamps();
        });

        Schema::create('user_voucher', function (Blueprint $table) {
            $table->unsignedInteger('user_id');
            $table->unsignedInteger('voucher_id');

            $table->primary(['user_id', 'voucher_id']);

            $table->foreign('voucher_id')
                ->references('id')
                ->on('vouchers')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_voucher');
        Schema::dropIfExists('vouchers');
    }
}
