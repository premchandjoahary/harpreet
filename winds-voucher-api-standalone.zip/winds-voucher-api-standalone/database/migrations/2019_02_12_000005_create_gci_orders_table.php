<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGciOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('gci_orders', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('order_id');
            $table->unsignedTinyInteger('status')->index()->comment('The GCI order api status');
            $table->string('receipt', 50)->nullable()->comment('The successful voucher order receipt number');
            $table->string('error_message')->nullable();
            $table->json('request')->nullable()->comment('The full GCI order api request data');
            $table->json('response')->nullable()->comment('The full GCI order api response data');
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('order_id')
                ->references('id')
                ->on('orders')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('gci_orders');
    }
}
