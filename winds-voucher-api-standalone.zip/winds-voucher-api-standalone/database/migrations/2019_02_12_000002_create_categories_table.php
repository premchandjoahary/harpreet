<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCategoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name', 60)->unique();
            $table->boolean('active')->default(true)->comment('Is the category enabled by Winds admin');
            $table->timestamps();
        });

        Schema::create('category_voucher', function (Blueprint $table) {
            $table->unsignedInteger('category_id');
            $table->unsignedInteger('voucher_id');

            $table->primary(['category_id', 'voucher_id']);

            $table->foreign('category_id')
                ->references('id')
                ->on('categories')
                ->onDelete('cascade');

            $table->foreign('voucher_id')
                ->references('id')
                ->on('vouchers')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('category_voucher');
        Schema::dropIfExists('categories');
    }
}
