<style type="text/css">
    .tg {
        border-collapse: collapse;
        border-spacing: 0;
    }

    .tg td {
        font-family: Arial, sans-serif;
        font-size: 14px;
        padding: 10px 5px;
        border-style: solid;
        border-width: 1px;
        overflow: hidden;
        word-break: normal;
        border-color: black;
    }

    .tg th {
        font-family: Arial, sans-serif;
        font-size: 14px;
        font-weight: normal;
        padding: 10px 5px;
        border-style: solid;
        border-width: 1px;
        overflow: hidden;
        word-break: normal;
        border-color: black;
    }

    .tg .tg-0lax {
        text-align: left;
        vertical-align: top
    }
</style>

@if($addedVouchers->isNotEmpty())
<div>
    <p>Newly added vouchers: {{ $addedVouchers->count() }}</p>
    <p><strong>Newly added vouchers are disabled by default. Please enable them manually!</strong></p>

    <table class="tg">
        <tr>
            <th class="tg-0lax">ID</th>
            <th class="tg-0lax">Name</th>
            <th class="tg-0lax">Hash</th>
            <th class="tg-0lax">Created</th>
        </tr>
        @foreach($addedVouchers as $addedVoucher)
            <tr>
                <td class="tg-0lax">{{ $addedVoucher->id }}</td>
                <td class="tg-0lax">{{ $addedVoucher->name }}</td>
                <td class="tg-0lax">{{ $addedVoucher->hash }}</td>
                <td class="tg-0lax">{{ $addedVoucher->created_at->toDayDateTimeString() }}</td>
            </tr>
        @endforeach
    </table>
</div>
@endif

@if($removedVouchers->isNotEmpty())
    <div>
        <p>Removed vouchers: {{ $removedVouchers->count() }}</p>

        <table class="tg">
            <tr>
                <th class="tg-0lax">ID</th>
                <th class="tg-0lax">Name</th>
                <th class="tg-0lax">Hash</th>
                <th class="tg-0lax">Created</th>
            </tr>
            @foreach($removedVouchers as $removedVoucher)
                <tr>
                    <td class="tg-0lax">{{ $removedVoucher->id }}</td>
                    <td class="tg-0lax">{{ $removedVoucher->name }}</td>
                    <td class="tg-0lax">{{ $removedVoucher->hash }}</td>
                    <td class="tg-0lax">{{ $removedVoucher->created_at->toDayDateTimeString() }}</td>
                </tr>
            @endforeach
        </table>
    </div>
@endif
