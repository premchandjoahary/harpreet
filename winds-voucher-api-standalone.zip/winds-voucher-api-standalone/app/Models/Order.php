<?php

namespace App\Models;

class Order extends Model
{

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'orders';

    /**
     * Get gci order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function gciOrder()
    {
        return $this->hasOne(GciOrder::class, 'order_id', 'id');
    }
}
