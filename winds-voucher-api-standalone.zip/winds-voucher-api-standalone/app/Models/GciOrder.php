<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class GciOrder extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'gci_orders';

    /**
     * Get order related to gci order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function order()
    {
        return $this->belongsTo(Order::class, 'order_id', 'id');
    }
}
