<?php

namespace App\Models;

class Denomination extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'denominations';

    /**
     * The attributes type casting
     */
    protected $casts = [
        'active' => 'boolean',
        'enabled_by_provider' => 'boolean'
    ];

    /**
     * Voucher that the denomination belongs to.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function voucher()
    {
        return $this->belongsTo(Voucher::class, 'voucher_id', 'id');
    }
}
