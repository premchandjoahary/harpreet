<?php

namespace App\Models;

class Voucher extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'vouchers';

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = [
        'last_seeded_at'
    ];

    /**
     * The attributes type casting
     */
    protected $casts = [
        'active' => 'boolean',
        'enabled_by_provider' => 'boolean',
        'online' => 'boolean'
    ];

    /**
     * Voucher denominations.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function denominations()
    {
        return $this->hasMany(Denomination::class, 'voucher_id', 'id');
    }

    /**
     * Voucher categories.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function categories()
    {
        return $this->belongsToMany(Category::class, 'category_voucher', 'voucher_id', 'category_id');
    }
}
