<?php

namespace App\Models;

use Laravel\Scout\Searchable;

class VoucherIndex extends Model
{
    use Searchable;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'vouchers';

    /**
     * Get the index name for the model.
     *
     * @return string
     */
    public function searchableAs()
    {
        return config('scout.elasticsearch_vouchers_index');
    }

    /**
     * Get the indexable data array for the model.
     *
     * @return array
     */
    public function toSearchableArray()
    {
        if (! $this->active) {
            return [];
        }

        return ['name' => $this->name];
    }
}
