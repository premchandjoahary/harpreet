<?php

namespace App\Jobs\Voucher;

use DB;
use Mail;
use Exception;
use App\Models\Voucher;
use App\Models\Category;
use Illuminate\Bus\Queueable;
use App\Mail\VoucherSeederAlert;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Database\Eloquent\Collection;

class BrandSeeder
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** @var string */
    protected $accessToken;

    /** @var array */
    protected $newBrands = [];

    /** @var array */
    protected $disabledBrands = [];

    /**
     * Execute the job.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $this->accessToken = $this->getAccessToken();

        $brands = $this->getBrands();

        $this->updateBrands($brands);

        $this->triggerNotifications();
    }

    /**
     * Update the brands in database.
     *
     * @param array $brands
     * @throws Exception
     */
    protected function updateBrands(array $brands)
    {
        $brands = collect($brands);
        $existingBrands = Voucher::all();

        // When the brands API from GCI returns empty data.
        if ($brands->isEmpty()) {
            $this->disableAllBrands($existingBrands);
            return;
        }

        // Loop through each brand and add/update them in database.
        foreach ($brands as $brand) {
            $hash = data_get($brand, 'hash');

            $existingBrand = $existingBrands->where('hash', $hash)->first();

            DB::beginTransaction();
            try {
                if ($existingBrand) {
                    $this->updateExistingBrand($brand, $existingBrand);
                } else {
                    $this->addNewBrand($brand);
                }

                DB::commit();
            } catch (Exception $e) {
                DB::rollBack();

                log_exception($e);
            }
        }

        // Detect if any old brand has been removed from the new API response and disable them.
        $this->disableRemovedBrands($brands, $existingBrands);
    }

    /**
     * Add a new brand to the database.
     *
     * @param array $data
     */
    protected function addNewBrand($data)
    {
        $createData = $this->getFilteredBrandData($data);

        $voucher = Voucher::create($createData);

        $this->syncCategories($voucher, data_get($data, 'categories'));

        $this->newBrands[] = $voucher;
    }

    /**
     * Update an existing brand in the database.
     *
     * @param array $data
     * @param Voucher $voucher
     */
    protected function updateExistingBrand($data, Voucher $voucher)
    {
        $updateData = $this->getFilteredBrandData($data, true);

        $voucher->update($updateData);

        $this->syncCategories($voucher, data_get($data, 'categories'));
    }

    /**
     * Get the filtered brand data for insertion/updation in database.
     *
     * @param array $data
     * @param bool $forUpdate
     * @return array
     */
    protected function getFilteredBrandData($data, $forUpdate = false)
    {
        $data = [
            'name' => data_get($data, 'name'),
            'hash' => data_get($data, 'hash'),
            'active' => false,
            'delivery_type' => array_first(data_get($data, 'productTypes', [])) ?? 'Digital',
            'discount_type' => data_get($data, 'discountType'),
            'enabled_by_provider' => true,
            'online' => data_get($data, 'isOnline'),
            'offer_percentage' => data_get($data, 'offerPercentage'),
            'turn_around_time' => data_get($data, 'turnAroundTimeInDays', 2) * 24,
            'provider_image_url' => data_get($data, 'image'),
            'website' => data_get($data, 'website'),
            'description' => data_get($data, 'description'),
            'terms' => data_get($data, 'terms'),
            'last_seeded_at' => now(),
        ];

        if ($forUpdate) {
            unset($data['hash']);
            unset($data['active']);
        }

        return $data;
    }

    /**
     * Sync all the voucher categories.
     *
     * @param Voucher $voucher
     * @param array|string $categories
     */
    protected function syncCategories(Voucher $voucher, $categories)
    {
        $categories = collect(array_wrap($categories));

        $categoryIds = $categories->map(function ($category) {
            return Category::firstOrCreate(['name' => trim($category)])->id;
        });

        $voucher->categories()->sync($categoryIds);
    }

    /**
     * Disable all brands if the GCI API returns no brands.
     *
     * @param Collection $vouchers
     */
    protected function disableAllBrands(Collection $vouchers)
    {
        // If we do not have any data in the database then no action is required.
        if ($vouchers->isEmpty()) {
            return;
        }

        // If we have data in database then disable all the brands.
        $voucherIds = $vouchers->pluck('id')->toArray();

        Voucher::whereIn('id', $voucherIds)->update(['enabled_by_provider' => false]);
    }

    /**
     * Disable all the brands which were removed from GCI end.
     *
     * @param \Illuminate\Support\Collection $brands
     * @param Collection $vouchers
     */
    protected function disableRemovedBrands($brands, Collection $vouchers)
    {
        $removedVouchers = $vouchers->filter(function ($voucher) use ($brands) {
            // Remove the vouchers which existing in the latest brands API response.
            return $voucher->enabled_by_provider && ! $brands->contains('hash', $voucher->hash);
        });

        $voucherIds = $removedVouchers->pluck('id')->toArray();

        Voucher::whereIn('id', $voucherIds)->update(['enabled_by_provider' => false]);

        $this->disabledBrands = $removedVouchers;
    }

    /**
     * Trigger the new and removed brand email notifications.
     */
    protected function triggerNotifications()
    {
        $newBrandCount = count($this->newBrands);
        $disabledBrandCount = count($this->disabledBrands);

        if (! $newBrandCount && ! $disabledBrandCount) {
            return;
        }

        $subject = '[Voucher Alert] ';
        $subject .= $newBrandCount ? $newBrandCount . ' ' . str_plural('voucher', $newBrandCount) . ' added' : '';


        if ($disabledBrandCount) {
            $subject .= ($newBrandCount ? ' and ' : '');
            $subject .= $disabledBrandCount . ' ' . str_plural('voucher', $disabledBrandCount) . ' removed';
        }

        Mail::to(config('notification.seeder_alert_emails'))
            ->send(new VoucherSeederAlert($subject, collect($this->newBrands), collect($this->disabledBrands)));
    }

    /**
     * Get the GCI voucher brands.
     *
     * @return array
     * @throws Exception
     */
    protected function getBrands()
    {
        $result = gci()->getBrands($this->accessToken);

        if (! isset($result['brands'])) {
            throw new Exception('Unable to fetch GCI voucher brands.');
        }

        return $result['brands'];
    }

    /**
     * Get the GCI access token.
     *
     * @return string
     * @throws Exception
     */
    protected function getAccessToken()
    {
        $result = gci()->getAccessToken();

        if (! isset($result['accessToken'])) {
            throw new Exception('Unable to fetch GCI access token.');
        }

        return $result['accessToken'];
    }
}
