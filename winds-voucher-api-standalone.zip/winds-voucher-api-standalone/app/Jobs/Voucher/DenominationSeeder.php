<?php

namespace App\Jobs\Voucher;

use DB;
use Exception;
use App\Models\Voucher;
use App\Models\Denomination;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Database\Eloquent\Collection;

class DenominationSeeder
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** @var string */
    protected $accessToken;

    /** @var string|null */
    private $brandHash;

    /**
     * Create a new job instance.
     *
     * @param string|null $brandHash
     */
    public function __construct($brandHash = null)
    {
        $this->brandHash = $brandHash;
    }

    /**
     * Execute the job.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $this->accessToken = $this->getAccessToken();

        $vouchers = $this->getVouchers();

        $this->updateVoucherDenominations($vouchers);
    }

    /**
     * Update the brands in database.
     *
     * @param Collection $vouchers
     * @throws Exception
     */
    protected function updateVoucherDenominations($vouchers)
    {
        if ($vouchers->isEmpty()) {
            return;
        }

        // Loop through each voucher and add/update denominations in database.
        foreach ($vouchers as $voucher) {
            DB::beginTransaction();
            try {
                $denominations = $this->getDenominations($voucher->hash);

                $this->syncDenominations($voucher, $denominations);

                DB::commit();
            } catch (Exception $e) {
                DB::rollBack();

                log_exception($e);
            }
        }
    }

    /**
     * Sync the voucher denominations with the API response.
     *
     * @param Voucher $voucher
     * @param array $denominations
     */
    protected function syncDenominations(Voucher $voucher, $denominations)
    {
        $denominations = collect($denominations);
        $existingDenominations = $voucher->denominations;

        // When the denominations API from GCI returns empty data.
        if ($denominations->isEmpty()) {
            $this->disableAllDenominations($existingDenominations);
            return;
        }

        // Loop through each denomination and add/update them in database.
        foreach ($denominations as $denomination) {
            $providerId = data_get($denomination, 'id');

            $existingDenomination = $existingDenominations->where('provider_id', $providerId)->first();

            if ($existingDenomination) {
                $this->updateExistingDenomination($denomination, $existingDenomination);
            } else {
                $this->addNewDenomination($denomination, $voucher);
            }
        }

        // Detect if any old brand has been removed from the new API response and disable them.
        $this->disableRemovedDenominations($denominations, $existingDenominations);
    }

    /**
     * Add a new denomination to the database.
     *
     * @param array $data
     * @param Voucher $voucher
     */
    protected function addNewDenomination($data, Voucher $voucher)
    {
        $createData = $this->getFilteredDenominationData($data);

        $voucher->denominations()->create($createData);
    }

    /**
     * Update an existing denomination in the database.
     *
     * @param array $data
     * @param Denomination $denomination
     */
    protected function updateExistingDenomination($data, Denomination $denomination)
    {
        $updateData = $this->getFilteredDenominationData($data, true);

        $denomination->update($updateData);
    }

    /**
     * Get the filtered denomination data for insertion/updation in database.
     *
     * @param array $data
     * @param bool $forUpdate
     * @return array
     */
    protected function getFilteredDenominationData($data, $forUpdate = false)
    {
        $data = [
            'provider_id' => data_get($data, 'id'),
            'value' => data_get($data, 'name'),
            'sku_id' => data_get($data, 'skuId'),
            'value_type' => data_get($data, 'valueType'),
            'delivery_type' => data_get($data, 'type'),
            'active' => true,
            'enabled_by_provider' => true,
        ];

        if ($forUpdate) {
            unset($data['provider_id']);
            unset($data['active']);
        }

        return $data;
    }

    /**
     * Disable all denominations if the GCI API returns no data.
     *
     * @param Collection $existingDenominations
     */
    protected function disableAllDenominations(Collection $existingDenominations)
    {
        // If we do not have any data in the database then no action is required.
        if ($existingDenominations->isEmpty()) {
            return;
        }

        // If we have data in database then disable all the denominations.
        $denominationIds = $existingDenominations->pluck('id')->toArray();

        Denomination::whereIn('id', $denominationIds)->update(['enabled_by_provider' => false]);
    }

    /**
     * Disable all the denominations which were removed from GCI end.
     *
     * @param \Illuminate\Support\Collection $denomination
     * @param Collection $existingDenominations
     */
    protected function disableRemovedDenominations($denomination, Collection $existingDenominations)
    {
        $removedDenominations = $existingDenominations->filter(function ($existingDenomination) use ($denomination) {
            // Remove the denominations existing in the latest denominations API response.
            return $existingDenomination->enabled_by_provider
                && ! $denomination->contains('id', $existingDenomination->provider_id);
        });

        $denominationIds = $removedDenominations->pluck('id')->toArray();

        Denomination::whereIn('id', $denominationIds)->update(['enabled_by_provider' => false]);
    }

    /**
     * Get all the existing vouchers to seed the denominations.
     *
     * @return Collection
     */
    protected function getVouchers()
    {
        return Voucher::with('denominations')
            ->where('enabled_by_provider', true)
            ->when($this->brandHash, function ($query) {
                $query->where('hash', $this->brandHash);
            })
            ->get(['id', 'name', 'hash']);
    }

    /**
     * Get the GCI voucher denominations.
     *
     * @param string $hash
     * @return array
     * @throws Exception
     */
    protected function getDenominations($hash)
    {
        $result = gci()->getDenominations($this->accessToken, $hash);

        if (! isset($result['denominations'])) {
            throw new Exception('Unable to fetch GCI voucher denominations.');
        }

        return $result['denominations'];
    }

    /**
     * Get the GCI access token.
     *
     * @return string
     * @throws Exception
     */
    protected function getAccessToken()
    {
        $result = gci()->getAccessToken();

        if (! isset($result['accessToken'])) {
            throw new Exception('Unable to fetch GCI access token.');
        }

        return $result['accessToken'];
    }
}
