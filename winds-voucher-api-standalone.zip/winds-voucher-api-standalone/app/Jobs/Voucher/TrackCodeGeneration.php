<?php

namespace App\Jobs\Voucher;

use DB;
use Exception;
use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Database\Eloquent\Collection;

class TrackCodeGeneration
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    const FULFILLED = 3;

    /** @var string */
    protected $accessToken;

    /**
     * Execute the job.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        $orders = $this->getOrders();

        if ($orders->isEmpty()) {
            return;
        }

        $this->accessToken = $this->getAccessToken();

        $this->updateVoucherCodeFlag($orders);
    }

    /**
     * Update the voucher code generated flag.
     *
     * @param Collection $orders
     * @throws Exception
     */
    protected function updateVoucherCodeFlag($orders)
    {
        foreach ($orders as $order) {
            if($order->gciOrder->receipt) {
                DB::beginTransaction();
                try {
                    $receipt = $order->gciOrder->receipt;

                    $result = gci()->getVoucherCode($this->accessToken, $receipt);

                    if($result) {
                        $order->update([
                            'voucher_code_generated' => true
                        ]);
                    }

                    DB::commit();
                } catch (Exception $e) {
                    DB::rollBack();

                    log_exception($e);
                }
            }
        }

    }

    /**
     * Get all the existing order to update voucher code flag.
     *
     * @return Collection
     */
    protected function getOrders()
    {
        return Order::whereHas('gciOrder')->where('status', self::FULFILLED)
                ->where('voucher_code_generated', false)
                ->get();
    }

    /**
     * Get the GCI access token.
     *
     * @return string
     * @throws Exception
     */
    protected function getAccessToken()
    {
        $result = gci()->getAccessToken();

        if (! isset($result['accessToken'])) {
            throw new Exception('Unable to fetch GCI access token.');
        }

        return $result['accessToken'];
    }
}
