<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Jobs\Voucher\DenominationSeeder;

class VoucherDenominationsSeeder extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'voucher:seed-denominations {--b|brand= : The brand hash to seed the denominations}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Seed all the voucher brand denominations and sync denomination information.';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info('Seeder started');

        dispatch(new DenominationSeeder($this->option('brand')));

        $this->info('Seeder completed');
    }
}
