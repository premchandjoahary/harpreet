<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Jobs\Voucher\BrandSeeder;

class VoucherBrandsSeeder extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'voucher:seed-brands';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Seed all the voucher brands and sync brand information.';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info('Seeder started');

        dispatch(new BrandSeeder());

        $this->info('Seeder completed');
    }
}
