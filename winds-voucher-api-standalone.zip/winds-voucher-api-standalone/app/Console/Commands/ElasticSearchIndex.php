<?php

namespace App\Console\Commands;

use Exception;
use App\Models\VoucherIndex;
use Illuminate\Console\Command;
use Elasticsearch\ClientBuilder;
use Illuminate\Support\Facades\Artisan;

class ElasticSearchIndex extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'elasticsearch:create-voucher-index';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create elastic search index for voucher';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        $client = ClientBuilder::create()->setHosts([config('scout.elasticsearch_host')])->build();

        $this->info('Trying to delete existing index');

        try {
            $response = $client->indices()->delete([
                'index' => config('scout.elasticsearch_vouchers_index'),
            ]);

            $this->info('Index deleted successfully');

        } catch (Exception $e) {
            $this->info('Index was initially absent');
        }

        $this->info('Creating new index');

        $params = [
            'index' => config('scout.elasticsearch_vouchers_index'),
            'body' => [
                'mappings' => [
                    config('scout.elasticsearch_vouchers_index') => [
                        'properties' => [
                            'name' => [
                                'type' => 'text'
                            ],
                        ]
                    ]
                ]
            ]
        ];

        // Create the index
        $response = $client->indices()->create($params);

        $this->info('Ingesting the model');

        Artisan::call('scout:import', [
            'model' => VoucherIndex::class
        ]);

        $this->info('Successfully ingested the model');
    }
}
