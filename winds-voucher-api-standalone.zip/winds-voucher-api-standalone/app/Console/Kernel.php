<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        if (app()->environment('production')) {
            $voucherCodeGenerateKey = config('cronitor.voucher_code_generation_key');

            $schedule->command('voucher:track-code-generation')
                ->everyThirtyMinutes()
                ->cronitor($voucherCodeGenerateKey);
        }

        $voucherBrandSeederKey = config('cronitor.voucher_brand_seeder_key');

        $schedule->command('voucher:seed-brands')
            ->dailyAt('1:00')
            ->cronitor($voucherBrandSeederKey);

        $voucherDenominationSeederKey = config('cronitor.voucher_denomination_seeder_key');

        $schedule->command('voucher:seed-denominations')
            ->dailyAt('1:00')
            ->cronitor($voucherDenominationSeederKey);
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
