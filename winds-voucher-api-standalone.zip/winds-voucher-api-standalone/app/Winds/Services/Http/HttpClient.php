<?php

namespace App\Winds\Services\Http;

use Exception;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\BadResponseException;

class HttpClient
{
    const RESPONSE_TYPE_JSON = 'json';

    /** @var \GuzzleHttp\Client */
    protected $client;

    /** @var array */
    protected $headers;

    /** @var array */
    protected $queryString;

    /** @var array */
    protected $postBody;

    /** @var array */
    protected $jsonBody;

    /** @var string */
    protected $url;

    /** @var mixed */
    protected $timeout = 60;

    /** @var string */
    protected $responseType = self::RESPONSE_TYPE_JSON;

    /**
     * HttpClient constructor.
     *
     * @param \GuzzleHttp\Client $client
     */
    public function __construct(Client $client)
    {
        $this->client = $client;
    }

    /**
     * HTTP Get Request.
     *
     * @param       $url
     * @param array $params
     * @param array $header
     *
     * @return array
     * @throws Exception
     */
    public function get($url, $params = [], $header = [])
    {
        if ($this->hasUrlQueries($url)) {
            $queryParams = $this->getUrlQueries($url);
            $params = $this->addQueryParams($params, $queryParams);
        }

        return $this->setHeaders($header)->setQueryString($params)->sendRequest($url);
    }

    /**
     * HTTP Post Request.
     *
     * @param       $url
     * @param array $params
     * @param array $header
     *
     * @return array
     * @throws Exception
     */
    public function post($url, $params = [], $header = [])
    {
        return $this->setHeaders($header)->setRequestBody($params)->sendRequest($url, 'POST');
    }

    /**
     * HTTP Put Request.
     *
     * @param       $url
     * @param array $params
     * @param array $header
     *
     * @return array
     * @throws Exception
     */
    public function put($url, $params = [], $header = [])
    {
        return $this->setHeaders($header)->setRequestBody($params)->sendRequest($url, 'PUT');
    }

    /**
     * HTTP Delete Request.
     *
     * @param       $url
     * @param array $params
     * @param array $header
     *
     * @return array
     * @throws Exception
     */
    public function delete($url, $params = [], $header = [])
    {
        return $this->setHeaders($header)->setRequestBody($params)->sendRequest($url, 'DELETE');
    }

    /**
     * Set the connection timeout.
     *
     * @param mixed $timeout
     */
    public function setTimeout($timeout)
    {
        $this->timeout = $timeout;
    }

    /**
     * Set the request headers.
     *
     * @param array $headers
     *
     * @return $this
     */
    public function setHeaders($headers = [])
    {
        if (! empty($headers)) {
            $this->headers = $headers;
        }

        return $this;
    }

    /**
     * Sets a expected response type to 'JSON'.
     *
     * @return $this
     */
    public function setJsonResponseType()
    {
        $this->responseType = self::RESPONSE_TYPE_JSON;

        return $this;
    }

    /**
     * Send the HTTP Request.
     *
     * @param        $url
     * @param string $method
     *
     * @return array
     * @throws Exception
     */
    protected function sendRequest($url, $method = 'GET')
    {
        return $this->setUrl($url)->makeRequest($method);
    }

    /**
     * Make Http Request.
     *
     * @param string $method
     * @return array
     * @throws Exception
     */
    protected function makeRequest($method)
    {
        $response = ['code' => 200, 'data' => null];
        $responseData = null;

        try {
            $request = $this->client->request($method, $this->url, [
                'query' => $this->getQueryString(),
                'form_params' => $this->getPostBody(),
                'json' => $this->getJsonBody(),
                'headers' => $this->headers,
                'connect_timeout' => $this->timeout
            ]);

            $responseBody = $request->getBody();
            $response['data'] = $responseData = json_decode($responseBody, true);

            if ($this->responseType === self::RESPONSE_TYPE_JSON && ! $this->isValidJson($responseBody, true)) {
                $response['message'] = 'Http Request Response is not a valid Json.';
                $response['data'] = (string) $responseBody;
                throw new Exception(json_encode($response));
            }
        } catch (BadResponseException $e) {
            $responseBody = (string) $e->getResponse()->getBody();

            $response = [
                'code' => $e->getResponse()->getStatusCode(),
                'message' => "Http Request resulted in a Bad Response with a code: {$e->getCode()}.",
                'data' => $responseBody,
            ];

            // If the denominations are not set for the brand then fail gracefully.
            if (str_contains($responseBody, 'EMPTY_RESULT')) {
                return [
                    'denominations' => []
                ];
            }

            log_exception($e);

            throw new Exception(json_encode($response));
        }

        return $responseData;
    }

    /**
     * Set the request url.
     *
     * @param string $url
     *
     * @return $this
     */
    protected function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    /**
     * Check for content type is set to 'application/json'.
     *
     * @return bool
     */
    protected function isJsonContentType()
    {
        return data_get($this->headers, 'Content-Type') == 'application/json';
    }

    /**
     * Set request body params.
     *
     * @param array $params
     *
     * @return $this
     */
    protected function setRequestBody($params = [])
    {
        if ($this->isJsonContentType()) {
            return $this->setJsonBody($params);
        }

        return $this->setPostBody($params);
    }

    /**
     * Get request query string params.
     *
     * @return array
     */
    protected function getQueryString()
    {
        return $this->queryString;
    }

    /**
     * Set request query string params.
     *
     * @param array $queryString
     *
     * @return $this
     */
    protected function setQueryString($queryString = [])
    {
        $this->queryString = $queryString;

        return $this;
    }

    /**
     * Get request post body params.
     *
     * @return array
     */
    protected function getPostBody()
    {
        return $this->postBody;
    }

    /**
     * Set request post params.
     *
     * @param $postBody
     *
     * @return $this
     */
    protected function setPostBody($postBody = [])
    {
        $this->postBody = $postBody;

        return $this;
    }

    /**
     * Get request json body params.
     *
     * @return array
     */
    protected function getJsonBody()
    {
        return $this->jsonBody;
    }

    /**
     * Set request json body params.
     *
     * @param array $jsonBody
     *
     * @return $this
     */
    protected function setJsonBody($jsonBody = [])
    {
        $this->jsonBody = $jsonBody;

        return $this;
    }

    /**
     * Sets request parameters from url queries.
     *
     * @param array $params
     * @param array $urlQueries
     * @return array
     */
    protected function addQueryParams($params, $urlQueries)
    {

        foreach ($urlQueries as $key => $parameter) {
            if (! array_key_exists($key, $params)) {
                $params[$key] = $parameter;
            }
        }

        return $params;
    }

    /**
     * Checks if a given url has any query parameters.
     *
     * @param string $url
     * @return bool
     */
    protected function hasUrlQueries($url)
    {
        return (bool) count($this->getUrlQueries($url));
    }

    /**
     * Get url queries as an array.
     *
     * @param string $url
     * @return array
     */
    protected function getUrlQueries($url)
    {
        $queryUrl = parse_url($url, PHP_URL_QUERY);
        parse_str($queryUrl, $queryParams);

        return $queryParams;
    }

    /**
     * Check if the input is a valid JSON data.
     *
     * @param string $dataString
     * @param bool $isObjectOrArray
     * @return bool
     */
    protected function isValidJson(string $dataString, bool $isObjectOrArray = false)
    {
        $decoded = json_decode($dataString);
        $isValidJson = (! empty($decoded) ? true : false) && json_last_error() == JSON_ERROR_NONE;
        if ($isValidJson && $isObjectOrArray) {
            return ! is_int($decoded);
        }

        return $isValidJson;
    }
}
