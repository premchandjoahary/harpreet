<?php

namespace App\Winds\Services\GCI;

use Exception;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use App\Winds\Services\Http\HttpClient;
use Illuminate\Config\Repository as ConfigRepository;

class GCI
{
    const CONFIG_FILE = 'gci';

    /** @var HttpClient */
    protected $httpClient;

    /** @var ConfigRepository */
    protected $config;

    /** @var string */
    protected $gciId;

    /** @var mixed */
    protected $gciKey;

    /**
     * GCI constructor.
     *
     * @param HttpClient $httpClient
     * @param ConfigRepository $config
     */
    public function __construct(HttpClient $httpClient, ConfigRepository $config)
    {
        $this->config = $config;

        $this->httpClient = $httpClient;
        $this->httpClient->setHeaders(['Content-Type' => 'application/json']);

        $this->gciId = $this->config('credentials.id');
        $this->gciKey = $this->config('credentials.key');
    }

    /**
     * Get the access token.
     *
     * @return array
     * @throws Exception
     */
    public function getAccessToken()
    {
        $apiEndpoint = $this->getAccessTokenEndpoint();

        return $this->httpClient->get($apiEndpoint, [
            'id' => $this->gciId,
            'key' => $this->gciKey,
        ]);
    }

    /**
     * Get the brands.
     *
     * @param string $accessToken
     * @return array
     * @throws Exception
     */
    public function getBrands($accessToken)
    {
        $apiEndpoint = $this->getBrandsEndpoint($accessToken);

        return $this->httpClient->post($apiEndpoint);
    }

    /**
     * Get the denominations.
     *
     * @param string $accessToken
     * @param string $hash
     * @return array
     * @throws Exception
     */
    public function getDenominations($accessToken, $hash)
    {
        $apiEndpoint = $this->getDenominationsEndpoint($accessToken, $hash);

        return $this->httpClient->post($apiEndpoint);
    }

    /**
     * @param $accessToken
     * @param $receipt
     * @return array
     * @throws Exception
     */
    public function getVoucherCode($accessToken, $receipt)
    {
        $apiEndpoint = $this->getOrderGetEndpoint($accessToken, $receipt);

        return $this->httpClient->post($apiEndpoint);
    }

    /**
     * Check if sandbox mode is enabled.
     *
     * @return bool
     */
    public function isSandboxEnabled()
    {
        return (bool) $this->config('sandbox_mode');
    }

    /**
     * Get the access token API endpoint url.
     *
     * @return string
     * @throws Exception
     */
    protected function getAccessTokenEndpoint()
    {
        return $this->getApiUrl('access_token');
    }

    /**
     * Get the brands API endpoint url.
     *
     * @param string $accessToken
     * @return string
     * @throws Exception
     */
    protected function getBrandsEndpoint($accessToken)
    {
        return $this->getApiUrl('brands', compact('accessToken'));
    }

    /**
     * Get the denominations API endpoint url.
     *
     * @param string $accessToken
     * @param string $hash
     * @return string
     * @throws Exception
     */
    protected function getDenominationsEndpoint($accessToken, $hash)
    {
        return $this->getApiUrl('denominations', compact('accessToken', 'hash'));
    }

    /**
     * Get the order add API endpoint url.
     *
     * @param string $accessToken
     * @return string
     * @throws Exception
     */
    protected function getOrderAddEndpoint($accessToken)
    {
        return $this->getApiUrl('order.add', compact('accessToken'));
    }

    /**
     * Get the order fetch API endpoint url.
     *
     * @param string $accessToken
     * @param mixed $receipt
     * @return string
     * @throws Exception
     */
    protected function getOrderGetEndpoint($accessToken, $receipt)
    {
        return $this->getApiUrl('order.get', compact('accessToken', 'receipt'));
    }

    /**
     * Get the order acknowledgement API endpoint url.
     *
     * @param string $accessToken
     * @param mixed $clientOrderId
     * @return string
     * @throws Exception
     */
    protected function getOrderAcknowledgementEndpoint($accessToken, $clientOrderId)
    {
        return $this->getApiUrl('order.acknowledgement', compact('accessToken', 'clientOrderId'));
    }

    /**
     * Get the gift card balance API endpoint url.
     *
     * @param string $accessToken
     * @return string
     * @throws Exception
     */
    protected function getCardBalanceEndpoint($accessToken)
    {
        return $this->getApiUrl('card_balance', compact('accessToken'));
    }

    /**
     * Get the partner balance API endpoint url.
     *
     * @param string $accessToken
     * @return string
     * @throws Exception
     */
    protected function getPartnerBalanceEndpoint($accessToken)
    {
        return $this->getApiUrl('partner_balance', compact('accessToken'));
    }

    /**
     * Get the access token API endpoint url.
     *
     * @param string $endpoint
     * @param array $queryParams
     * @return string
     * @throws Exception
     */
    protected function getApiUrl(string $endpoint, $queryParams = [])
    {
        $endpointUrl = $this->config("api_endpoints.{$endpoint}");

        if (! $endpointUrl) {
            throw new Exception("GCI endpoint not configured [{$endpoint}]");
        }

        $baseUrl = $this->config('api_base_url');

        $endpointUrl = $this->cleanUrl($baseUrl, $endpointUrl);

        if (empty($queryParams)) {
            return $endpointUrl;
        }

        return $endpointUrl . (Str::contains($endpointUrl, '?') ? '&' : '?') . Arr::query($queryParams);
    }

    /**
     * @param string $key
     * @param null $default
     * @return mixed
     */
    protected function config(string $key, $default = null)
    {
        return $this->config->get(self::CONFIG_FILE . '.' . $key, $default);
    }

    /**
     * Generate the clean url given the base url and it's optional segment.
     *
     * @param string $url
     * @param string|null $segment
     * @return string
     */
    protected function cleanUrl(string $url, string $segment = null)
    {
        $url = rtrim(trim($url), '/');

        return is_null($segment) ? $url : ($url . '/' . trim($segment, '/'));
    }
}
