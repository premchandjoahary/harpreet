<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VoucherSeederAlert extends Mailable
{
    use Queueable, SerializesModels;

    /** @var \Illuminate\Support\Collection */
    public $addedVouchers;

    /** @var \Illuminate\Support\Collection */
    public $removedVouchers;

    /**
     * Create a new message instance.
     *
     * @param string $subject
     * @param \Illuminate\Support\Collection $addedVouchers
     * @param \Illuminate\Support\Collection $removedVouchers
     */
    public function __construct($subject, $addedVouchers, $removedVouchers)
    {
        $this->subject = $subject;
        $this->addedVouchers = $addedVouchers;
        $this->removedVouchers = $removedVouchers;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('email.voucher-seeder-alert');
    }
}
