<?php

namespace App\Providers;

use App\Helpers\Cronitor;
use Illuminate\Console\Scheduling\Event;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Event::macro('cronitor', function ($code) {
            if (! $code || app_environment('local')) {
                return $this;
            }

            return $this->pingBefore(Cronitor::run($code))
                ->thenPing(Cronitor::complete($code));
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
