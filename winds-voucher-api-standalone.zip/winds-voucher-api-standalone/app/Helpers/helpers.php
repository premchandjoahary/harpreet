<?php

use Carbon\Carbon;
use App\Winds\Services\GCI\GCI;

if (! function_exists('app_environment')) {
    /**
     * Get or check the current application environment.
     *
     * @param mixed $args
     * @return bool|string
     */
    function app_environment(...$args)
    {
        return app()->environment(...$args);
    }
}

if (! function_exists('app_debug_enabled')) {
    /**
     * Check if the app debug is enabled.
     *
     * @return bool
     */
    function app_debug_enabled()
    {
        return config('app.debug', false);
    }
}

if (! function_exists('app_debug_disabled')) {
    /**
     * Check if the app debug is disabled.
     *
     * @return bool
     */
    function app_debug_disabled()
    {
        return ! app_debug_enabled();
    }
}

if (! function_exists('to_carbon')) {
    /**
     * Create a carbon instance from a string.
     *
     * @param string $time
     * @return \Carbon\Carbon
     */
    function to_carbon($time)
    {
        return Carbon::parse($time);
    }
}

if (! function_exists('ip')) {
    /**
     * Get the client IP address.
     *
     * @return string
     */
    function ip()
    {
        return request()->ip();
    }
}

if (! function_exists('log_exception')) {
    /**
     * Log the exception.
     *
     * @param Throwable $exception
     */
    function log_exception(Throwable $exception)
    {
        if (app()->environment('local')) {
            Log::error($exception);
        }

        if (app()->environment('staging') || app()->environment('production')) {
            Bugsnag::notifyException($exception);
        }
    }
}

if (! function_exists('prettify')) {
    /**
     * Prettify the given value.
     *
     * Sample result:
     *  name            Name
     *  age             Age
     *  created_at      Created At
     *  totalAmount     Total Amount
     *  birth_date      Birth Date
     *  theirPetName    Their Pet Name
     *  some-value      Some Value
     *
     * @param string $value
     * @return string
     */
    function prettify($value)
    {
        return title_case(snake_case(camel_case($value), ' '));
    }
}

if (! function_exists('gci')) {
    /**
     * Create a new GCI service instance.
     *
     * @return GCI
     */
    function gci()
    {
        return app(GCI::class);
    }
}
