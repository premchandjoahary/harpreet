<?php

namespace App\Helpers;

class Cronitor
{
    const BASE_URL = 'https://cronitor.link';

    /**
     * Generate the run ping link.
     *
     * @param string $key
     * @return string
     */
    public static function run(string $key)
    {
        return self::getBaseUrl() . "/{$key}/run";
    }

    /**
     * Generate the complete ping link.
     *
     * @param string $key
     * @return string
     */
    public static function complete(string $key)
    {
        return self::getBaseUrl() . "/{$key}/complete";
    }

    /**
     * Get the cronitor base ping url.
     *
     * @return \Illuminate\Config\Repository|mixed
     */
    public static function getBaseUrl()
    {
        return config('cronitor.base_url', self::BASE_URL);
    }
}
