#!/bin/bash

php artisan ide-helper:generate

php artisan ide-helper:meta

# Database connection should be active to generate model helper file
php artisan ide-helper:models -N
