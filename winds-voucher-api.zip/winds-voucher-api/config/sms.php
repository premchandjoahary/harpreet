<?php

// The default SMS Sender ID to use when one is not provided.
$defaultSenderId = env('SMS_SENDER_ID', 'EWINDS');

return [

    /*
    |--------------------------------------------------------------------------
    | SMS Driver
    |--------------------------------------------------------------------------
    |
    | The default driver to use.
    |
    | Supported: "gupshup", "msg91", "trap", "log"
    |
    */

    'driver' => env('SMS_DRIVER', 'log'),

    /*
    |--------------------------------------------------------------------------
    | Max Message Limit
    |--------------------------------------------------------------------------
    |
    | The maximum character limit allowed when sending messages.
    |
    */

    'message_limit' => env('SMS_MESSAGE_LIMIT', 1500),

    /*
    |--------------------------------------------------------------------------
    | SMS Providers
    |--------------------------------------------------------------------------
    |
    | The available SMS providers.
    |
    */

    'providers' => [

        'gupshup' => [
            'transport' => Winds\LaravelSMS\Transport\GupshupTransport::class,
            'user_id' => env('GUPSHUP_USER_ID'),
            'password' => env('GUPSHUP_PASSWORD'),
            'api_base_url' => env('GUPSHUP_API_BASE_URL', 'https://enterprise.smsgupshup.com/GatewayAPI/rest'),
        ],

        'msg91' => [
            'transport' => Winds\LaravelSMS\Transport\Msg91Transport::class,
            'auth_key' => env('MSG91_AUTH_KEY'),
            'transactional_sender_id' => env('MSG91_TRANSACTIONAL_SENDER_ID', $defaultSenderId),
            'promotional_sender_id' => env('MSG91_PROMOTIONAL_SENDER_ID', $defaultSenderId),
            'api_base_url' => env('MSG91_API_BASE_URL', 'https://api.msg91.com'),
        ],

        'trap' => [
            'transport' => Winds\LaravelSMS\Transport\TrapTransport::class,
            'email' => env('SMS_TRAP_EMAIL'),
        ],

        'log' => [
            'transport' => Winds\LaravelSMS\Transport\LogTransport::class,
            'log_channel' => env('SMS_LOG_CHANNEL'),
        ],

    ],

];
