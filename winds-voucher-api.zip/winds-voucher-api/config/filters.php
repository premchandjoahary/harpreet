<?php

return [

    'limit' => [
        'default' => 10,
        'min' => 3,
        'max' => 50,
    ],

];
