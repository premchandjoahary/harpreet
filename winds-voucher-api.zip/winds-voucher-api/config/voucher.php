<?php

return [

    // Payment gateway charge to be applied in percentage.
    'payment_gateway_charge_rate' => env('PG_CHARGE_RATE', 2),

    // The base url where the voucher images are hosted.
    'image_base_url' => env('IMAGE_BASE_URL'),

    // Verify the voucher availability with GCI before placing the order.
    'verify_voucher_pre_order' => env('VERIFY_VOUCHER_PRE_ORDER', true),

];
