<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Encryption Keys
    |--------------------------------------------------------------------------
    |
    | Passport uses encryption keys while generating secure access tokens for
    | your application. By default, the keys are stored as local files but
    | can be set via environment variables when that is more convenient.
    |
    */

    'private_key' => env('SSO_PRIVATE_KEY'),

    'public_key' => env('SSO_PUBLIC_KEY'),

    /*
    |--------------------------------------------------------------------------
    | Database
    |--------------------------------------------------------------------------
    |
    | The oauth database connection
    |
    */

    'database_connection' => [
        'driver' => 'mysql',
        'host' => env('OAUTH_DB_HOST', '127.0.0.1'),
        'port' => env('OAUTH_DB_PORT', '3306'),
        'database' => env('OAUTH_DB_NAME', 'forge'),
        'username' => env('OAUTH_DB_USERNAME', 'forge'),
        'password' => env('OAUTH_DB_PASSWORD', ''),
        'unix_socket' => env('OAUTH_DB_SOCKET', ''),
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => null,
    ],

];
