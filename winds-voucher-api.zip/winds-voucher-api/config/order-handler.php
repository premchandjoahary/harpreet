<?php

$sandboxMode = env('PAYMENT_SANDBOX_MODE', false);

return [

    'payment' => [
        'sandbox_mode' => $sandboxMode,
        'razorpay_key' => $sandboxMode ? env('TEST_RAZORPAY_KEY') : env('RAZORPAY_KEY'),
        'razorpay_secret' => $sandboxMode ? env('TEST_RAZORPAY_SECRET') : env('RAZORPAY_SECRET'),
    ],

    /*
     * The master orders table model.
     * If modified it should extend the Winds\OrderHandler\Models\Order model.
     */
    'orders_model' => \Winds\OrderHandler\Models\Order::class,

    /*
     * The master payments table model.
     * If modified it should extend the Winds\OrderHandler\Models\Payment model.
     */
    'payments_model' => \Winds\OrderHandler\Models\Payment::class,

    /*
     * The database connection hosting the orders and payments table.
     */
    'database_connection' => [
        'driver' => 'mysql',
        'host' => env('ORDERS_PAYMENTS_DB_HOST', '127.0.0.1'),
        'port' => env('ORDERS_PAYMENTS_DB_PORT', '3306'),
        'database' => env('ORDERS_PAYMENTS_DB_NAME', 'forge'),
        'username' => env('ORDERS_PAYMENTS_DB_USERNAME', 'forge'),
        'password' => env('ORDERS_PAYMENTS_DB_PASSWORD', ''),
        'unix_socket' => env('ORDERS_PAYMENTS_DB_SOCKET', ''),
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => null,
    ],
];
