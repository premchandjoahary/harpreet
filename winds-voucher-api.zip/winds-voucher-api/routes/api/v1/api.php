<?php

// List all vouchers
Route::get('vouchers', 'VoucherController@index');

// List all popular vouchers
Route::get('vouchers/popular', 'VoucherController@popular');

// Get all voucher filters
Route::get('filters', 'VoucherController@filters');

// Get the cart details
Route::post('cart-details', 'ShoppingCartController@details');

Route::group(['middleware' => 'auth'], function () {

    // Get all bookmarked vouchers
    Route::get('vouchers/bookmarked', 'VoucherController@bookmarked');

    // Bookmark a voucher
    Route::post('vouchers/{voucher}/bookmark', 'BookmarkController@store');

    // Remove voucher bookmark
    Route::delete('vouchers/{voucher}/bookmark', 'BookmarkController@delete');

    // List all voucher orders
    Route::get('orders', 'OrderController@index');

    // Get a single order
    Route::get('orders/{order}', 'OrderController@show');

    // Create a new order
    Route::post('initiate-order', 'OrderController@store');

    // Fulfill an order
    Route::post('orders/{order}/fulfill', 'OrderController@process');

    // Get a voucher code
    Route::get('order/{order}/code', 'VoucherController@voucherCode');

});

// Get a voucher details
Route::get('vouchers/{voucher}', 'VoucherController@show');

// Get the GCI wallet balance
Route::get('wallet-balance', 'WalletController@balance')->middleware('auth-internal-client');
