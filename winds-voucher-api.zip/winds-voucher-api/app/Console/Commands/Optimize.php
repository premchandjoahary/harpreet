<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class Optimize extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'winds:optimize';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Run all the Laravel deployment optimization commands';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->comment('Executing config cache command');
        $this->call('config:cache');

        $this->comment('Executing route cache command');
        $this->call('route:cache');

        $this->comment('Executing view cache command');
        $this->call('view:cache');

        $this->comment('Optimization complete!');
    }
}
