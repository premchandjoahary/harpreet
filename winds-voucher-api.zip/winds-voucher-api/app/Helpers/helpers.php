<?php

use Carbon\Carbon;
use App\Winds\Services\GCI\GCI;

if (! function_exists('app_environment')) {
    /**
     * Get or check the current application environment.
     *
     * @param mixed $args
     * @return bool|string
     */
    function app_environment(...$args)
    {
        return app()->environment(...$args);
    }
}

if (! function_exists('app_debug_enabled')) {
    /**
     * Check if the app debug is enabled.
     *
     * @return bool
     */
    function app_debug_enabled()
    {
        return config('app.debug', false);
    }
}

if (! function_exists('app_debug_disabled')) {
    /**
     * Check if the app debug is disabled.
     *
     * @return bool
     */
    function app_debug_disabled()
    {
        return ! app_debug_enabled();
    }
}

if (! function_exists('token')) {
    /**
     * Get the CSRF token value.
     *
     * @return string
     */
    function token()
    {
        return csrf_token();
    }
}

if (! function_exists('to_carbon')) {
    /**
     * Create a carbon instance from a string.
     *
     * @param string $time
     * @return \Carbon\Carbon
     */
    function to_carbon($time)
    {
        return Carbon::parse($time);
    }
}

if (! function_exists('ip')) {
    /**
     * Get the client IP address.
     *
     * @return string
     */
    function ip()
    {
        return request()->ip();
    }
}

if (! function_exists('log_exception')) {
    /**
     * Log the exception.
     *
     * @param Throwable $exception
     */
    function log_exception(Throwable $exception)
    {
        if (app()->environment('local')) {
            Log::error($exception);
        }

        if (app()->environment('staging') || app()->environment('production')) {
            Bugsnag::notifyException($exception);
        }
    }
}

if (! function_exists('display_rupees')) {
    /**
     * Format a number to display a indian currency.
     *
     * @param mixed $amount
     * @param int $decimals
     * @return string
     */
    function display_rupees($amount, $decimals = 2)
    {
        return '₹ ' . number_format($amount, $decimals);
    }
}

if (! function_exists('file_path')) {
    /**
     * Get the full file path given the folder path and file name.
     *
     * @param string $path
     * @param string $filename
     * @param string $folder The folder inside the path
     * @return string
     */
    function file_path($path, $filename, $folder = null)
    {
        return rtrim($path, '/') . ($folder ? "/{$folder}/" : '/') . $filename;
    }
}

if (! function_exists('folder_merge')) {
    /**
     * Get the full folder path after merging all the provided paths.
     *
     * @param array $folders The folders to merge
     * @return string
     */
    function folder_merge(...$folders)
    {
        return array_reduce($folders, function ($result, $folder) {
            return $result . trim($folder, '/') . '/';
        });
    }
}

if (! function_exists('str_clean')) {
    /**
     * Trim and convert the string to lower case.
     *
     * @param string $value
     * @return string
     */
    function str_clean($value)
    {
        return mb_strtolower(trim($value));
    }
}

if (! function_exists('str_replacer')) {
    /**
     * Replace all the placeholders with their values defined by the replacer array.
     *
     * @param string $subject
     * @param array $replace
     * @return string
     */
    function str_replacer($subject, array $replace)
    {
        if (empty($replace)) {
            return $subject;
        }

        foreach ($replace as $key => $value) {
            $subject = preg_replace("/:{$key}\b/i", (string)$value, $subject);
        }

        return $subject;
    }
}

if (! function_exists('limit_value')) {
    /**
     * Limit the given input value between the min and max value.
     *
     * @param mixed $value
     * @param mixed $min
     * @param mixed $max
     * @return mixed
     */
    function limit_value($value, $min, $max)
    {
        return min(max($value, $min), $max);
    }
}

if (! function_exists('prettify')) {
    /**
     * Prettify the given value.
     *
     * Sample result:
     *  name            Name
     *  age             Age
     *  created_at      Created At
     *  totalAmount     Total Amount
     *  birth_date      Birth Date
     *  theirPetName    Their Pet Name
     *  some-value      Some Value
     *
     * @param string $value
     * @return string
     */
    function prettify($value)
    {
        return title_case(snake_case(camel_case($value), ' '));
    }
}

if (! function_exists('array_to_object')) {
    /**
     * Convert an array to object.
     *
     * @param array $array
     * @param bool $recursive
     * @return object
     */
    function array_to_object(array $array, $recursive = true)
    {
        return json_decode(json_encode($array, $recursive ? JSON_FORCE_OBJECT : 0));
    }
}

if (! function_exists('filter')) {
    /**
     * Get the Query String Filter instance.
     *
     * @param \Illuminate\Database\Eloquent\Builder $builder
     * @param \Illuminate\Http\Resources\Json\JsonResource|\Illuminate\Http\Resources\Json\ResourceCollection $resource
     * @param \App\Winds\Libraries\QueryFilter\FilterContract|string $customFilter
     * @return \App\Winds\Libraries\QueryFilter\QueryFilterContract
     * @throws \Exception
     */
    function filter($builder = null, $resource = null, $customFilter = null)
    {
        /** @var \App\Winds\Libraries\QueryFilter\QueryFilterContract $queryFilter */
        $queryFilter = app('query-filter');

        if ($builder !== null) {
            $queryFilter = $queryFilter->builder($builder);
        }

        if ($resource !== null) {
            $queryFilter = $queryFilter->transformWith($resource);
        }

        if ($customFilter !== null) {
            $queryFilter = $queryFilter->customFilter($customFilter);
        }

        return $queryFilter;
    }
}

if (! function_exists('gci')) {
    /**
     * Create a new GCI service instance.
     *
     * @return GCI
     */
    function gci()
    {
        return app(GCI::class);
    }
}

if (! function_exists('include_route_files')) {
    /**
     * Loops through a folder and requires all PHP files
     * Searches sub-directories as well.
     *
     * @param string $folder
     */
    function include_route_files(string $folder)
    {
        $path = base_path('routes' . DIRECTORY_SEPARATOR . $folder);
        $rdi = new recursiveDirectoryIterator($path);
        $it = new recursiveIteratorIterator($rdi);

        while ($it->valid()) {
            if (! $it->isDot() && $it->isFile() && $it->isReadable() && $it->current()->getExtension() === 'php') {
                require $it->key();
            }

            $it->next();
        }
    }
}

if (! function_exists('resolve_boolean')) {

    /**
     * Resolves a string towards a boolean value.
     *
     * @param $value
     * @return bool
     */
    function resolve_boolean($value)
    {
        return filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }
}
