<?php

namespace App\Providers;

use Bugsnag;
use Bugsnag\Report;
use Illuminate\Support\ServiceProvider;
use Winds\OrderHandler\Constants\OrderMorphKey;
use Illuminate\Database\Eloquent\Relations\Relation;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        if (config('bugsnag.mobile_tracking')) {
            Bugsnag::registerCallback(function (Report $report) {

                $request = request();

                $report->addMetaData([
                    'mobile' => [
                        'appVersion' => $request->header('app-version'),
                        'os' => $request->header('device-os'),
                        'build' => $request->header('device-build'),
                    ]
                ]);
            });
        }

        $this->registerMorphMaps();
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Register the custom model morph maps.
     */
    protected function registerMorphMaps()
    {
        Relation::morphMap([
            OrderMorphKey::VOUCHER => \App\Models\Order::class,
            'User' => \App\Models\User::class,
        ]);
    }
}
