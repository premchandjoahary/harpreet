<?php

namespace App\Models;

class Category extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'categories';

    /**
     * The attributes type casting
     */
    protected $casts = [
        'active' => 'boolean'
    ];

    /**
     * Vouchers of category.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function vouchers()
    {
        return $this->belongsToMany(Voucher::class, 'category_voucher', 'category_id', 'voucher_id');
    }
}
