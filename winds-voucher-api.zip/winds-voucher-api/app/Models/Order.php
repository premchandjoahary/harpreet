<?php

namespace App\Models;

use Winds\OrderHandler\Traits\HasPayments;
use Illuminate\Database\Eloquent\SoftDeletes;
use Winds\OrderHandler\Traits\HasMasterOrder;

class Order extends Model
{
    use HasMasterOrder, HasPayments, SoftDeletes;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'orders';

    /**
     * The attributes that can be used for sorting with query string filtering.
     *
     * @var array
     */
    public $sortable = [
        'created_at'
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = [
        'deleted_at'
    ];

    /**
     * The user to who the order belongs to.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    /**
     * Get voucher purchased in the order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function voucher()
    {
        return $this->belongsTo(Voucher::class, 'voucher_id', 'id');
    }

    /**
     * Get denomination purchased in the order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function denomination()
    {
        return $this->belongsTo(Denomination::class, 'denomination_id', 'id');
    }

    /**
     * Get billing address related to order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function billingAddress()
    {
        return $this->belongsTo(Address::class, 'billing_address_id', 'id');
    }

    /**
     * Get shipping address related to order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function shippingAddress()
    {
        return $this->belongsTo(Address::class, 'shipping_address_id', 'id');
    }

    /**
     * Get gci order related to order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function gciOrder()
    {
        return $this->hasOne(GciOrder::class, 'order_id', 'id');
    }

    /**
     * Get the master order status text.
     *
     * @return string
     */
    public function getStatusText()
    {
        $statusMap = [
            0 => 'Payment Pending',
            1 => 'Payment Failed',
            2 => 'Fulfillment Pending',
            3 => 'Fulfilled',
            4 => 'Fulfillment Failed',
            5 => 'Refunded Initiate',
            6 => 'Payment Refunded',
            7 => 'Payment Complete',
            8 => 'User Cancelled',
        ];

        $masterOrder = $this->masterOrder;

        return $masterOrder && array_key_exists($masterOrder->status, $statusMap)
            ? $statusMap[$masterOrder->status]
            : 'Unknown';
    }
}
