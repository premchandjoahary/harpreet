<?php

namespace App\Models;

class Denomination extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'denominations';

    /**
     * The attributes type casting
     */
    protected $casts = [
        'active' => 'boolean',
        'enabled_by_provider' => 'boolean'
    ];

    /**
     * Scope a query to only include published denominations.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopePublished($query)
    {
        return $query->where('active', true)->where('enabled_by_provider', true);
    }

    /**
     * Voucher that the denomination belongs to.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function voucher()
    {
        return $this->belongsTo(Voucher::class, 'voucher_id', 'id');
    }

    /**
     * Get the orders made for the denomination.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orders()
    {
        return $this->hasMany(Order::class, 'denomination_id', 'id');
    }
}
