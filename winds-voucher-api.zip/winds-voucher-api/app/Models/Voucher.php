<?php

namespace App\Models;

class Voucher extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'vouchers';

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = [
        'last_seeded_at'
    ];

    /**
     * The attributes type casting
     */
    protected $casts = [
        'active' => 'boolean',
        'enabled_by_provider' => 'boolean',
        'online' => 'boolean'
    ];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = [
        'app_image_url', 'web_image_url', 'winds_rating'
    ];

    /**
     * Get the voucher app image url.
     *
     * @return string
     */
    public function getAppImageUrlAttribute()
    {
        return $this->getAppImageUrl();
    }

    /**
     * Get the voucher web image url.
     *
     * @return string
     */
    public function getWebImageUrlAttribute()
    {
        return $this->getWebImageUrl();
    }

    /**
     * Get the Winds voucher rating.
     *
     * @return int
     */
    public function getWindsRatingAttribute()
    {
        return $this->getWindsRating();
    }

    /**
     * Scope a query to only include published vouchers.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopePublished($query)
    {
        return $query->where('active', true)->where('enabled_by_provider', true);
    }

    /**
     * Scope a query to include the logged in user's voucher bookmark status.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeLoadBookmarkCount($query)
    {
        $user = auth()->user();

        return $query->when($user, function ($query) use ($user) {
            return $query->withCount(['bookmarkedUsers' => function ($query) use ($user) {
                $query->where('user_id', $user->id);
            }]);
        });
    }

    /**
     * Voucher denominations.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function denominations()
    {
        return $this->hasMany(Denomination::class, 'voucher_id', 'id')->published();
    }

    /**
     * Voucher categories.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function categories()
    {
        return $this->belongsToMany(Category::class, 'category_voucher', 'voucher_id', 'category_id');
    }

    /**
     * Get the orders made for the voucher.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orders()
    {
        return $this->hasMany(Order::class, 'voucher_id', 'id');
    }

    /**
     * Bookmarked users of the voucher.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function bookmarkedUsers()
    {
        return $this->belongsToMany(User::class, self::getDatabaseName() . '.user_voucher', 'voucher_id', 'user_id');
    }

    /**
     * Get the voucher app image url.
     *
     * @return string
     */
    public function getAppImageUrl()
    {
        if (! $this->uploaded_image_path) {
            return $this->provider_image_url;
        }

        return file_path($this->getBaseUrl(), $this->uploaded_image_path);
    }

    /**
     * Get the voucher app image url.
     *
     * @return string
     */
    public function getWebImageUrl()
    {
        if (! $this->web_image_path) {
            return $this->provider_image_url;
        }

        return file_path($this->getBaseUrl(), $this->web_image_path);
    }

    /**
     * Get base url of images.
     *
     * @return \Illuminate\Config\Repository|mixed
     */
    public function getBaseUrl()
    {
        return config('voucher.image_base_url');
    }

    /**
     * Get the Winds voucher rating.
     *
     * @return int
     */
    public function getWindsRating()
    {
        $commission = $this->offer_percentage;

        if ($commission >= 7) {
            return 7;
        }

        if ($commission >= 5 && $commission <= 6) {
            return 5;
        }

        return (int) ceil($commission);
    }

    /**
     * Retrieve the model for a bound value.
     *
     * @param mixed $value
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function resolveRouteBinding($value)
    {
        return $this->where('id', $value)->published()->firstOrFail();
    }
}
