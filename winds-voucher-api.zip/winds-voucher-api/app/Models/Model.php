<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model as BaseModel;

abstract class Model extends BaseModel
{
    /*
     * Any common model properties or logic goes here.
     * For example when using multi database connections, define the
     * default model connection here.
     */

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = [];

    /**
     * Create a new Eloquent model instance.
     * The constructor method is overwritten to append the database name to the table
     * to allow using laravel eloquent relationship over multiple database connections.
     *
     * @param array $attributes
     * @return void
     */
    public function __construct(array $attributes = [])
    {
        if (! $this->getConnectionName()) {
            $this->setConnection(config('database.default'));
        }

        $table = $this->getTable();

        if (! str_contains($table, '.') && ($database = $this->getConnection()->getDatabaseName())) {
            $this->setTable("{$database}.{$table}");
        }

        parent::__construct($attributes);
    }

    /**
     * Get the database name associated with the model.
     *
     * @return string
     */
    public static function getDatabaseName()
    {
        return (new static)->getConnection()->getDatabaseName();
    }

    /**
     * Get the fully qualified model table name with the database.
     *
     * @return string
     */
    public static function getQualifiedTableName()
    {
        $table = ($instance = new static)->getTable();

        if (str_contains($table, '.')) {
            return $table;
        }

        $database = $instance->getConnection()->getDatabaseName();

        return $database ? "{$database}.{$table}" : $table;
    }
}
