<?php

namespace App\Jobs\SMSNotification;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class SendFulfillmentSMS implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** @var mixed */
    private $order;
    /** @var mixed */
    private $number;

    /**
     * Create a new job instance.
     *
     * @param mixed $number
     * @param mixed $order
     * @return void
     */
    public function __construct($number, $order)
    {
        $this->number = $number;
        $this->order = $order;
    }

    /**
     * Execute the job.
     *
     * @throws \Winds\LaravelSMS\Exceptions\SMSException
     */
    public function handle()
    {
        $message = "Congratulations! You have successfully purchased a shopping voucher from ".$this->order->voucher->name." worth Rs. ".$this->order->total_amount.". Happy Shopping to you!";

        sms()->to($this->number)->message($message)->queue();
    }
}
