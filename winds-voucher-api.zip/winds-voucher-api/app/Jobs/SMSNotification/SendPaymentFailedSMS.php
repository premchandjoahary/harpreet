<?php

namespace App\Jobs\SMSNotification;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class SendPaymentFailedSMS implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** @var mixed */
    private $order;
    /** @var mixed */
    private $number;

    /**
     * Create a new job instance.
     *
     * @param mixed $order
     * @param mixed $number
     * @return void
     */
    public function __construct($number, $order)
    {
        $this->number = $number;
        $this->order = $order;
    }

    /**
     * Execute the job.
     *
     * @throws \Winds\LaravelSMS\Exceptions\SMSException
     */
    public function handle()
    {
        $message = "Sorry! Your ".$this->order->voucher->name." Voucher purchase of Rs. ".$this->order->total_amount." has failed. Please try again after sometime.";

        sms()->to($this->number)->message($message)->queue();
    }
}
