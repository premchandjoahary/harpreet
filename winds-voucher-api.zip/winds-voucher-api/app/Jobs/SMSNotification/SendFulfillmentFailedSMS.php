<?php

namespace App\Jobs\SMSNotification;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class SendFulfillmentFailedSMS implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** @var mixed */
    private $order;
    /** @var mixed */
    private $number;

    /**
     * Create a new job instance.
     *
     * @param mixed $number
     * @param mixed $order
     * @return void
     */
    public function __construct($number, $order)
    {
        $this->number = $number;
        $this->order = $order;
    }

    /**
     * Execute the job.
     *
     * @throws \Winds\LaravelSMS\Exceptions\SMSException
     */
    public function handle()
    {
        $message = "Your purchase from ".$this->order->voucher->name." was unsuccessful. Any amount debited from your account will be refunded within 24-48 hours.";

        sms()->to($this->number)->message($message)->queue();
    }
}
