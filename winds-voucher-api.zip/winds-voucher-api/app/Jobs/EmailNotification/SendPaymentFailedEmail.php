<?php

namespace App\Jobs\EmailNotification;

use Illuminate\Bus\Queueable;
use Illuminate\Support\Facades\Mail;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class SendPaymentFailedEmail implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** @var mixed */
    private $order;
    /** @var mixed */
    private $email;

    /**
     * Create a new job instance.
     *
     * @param mixed $order
     * @param mixed $email
     * @return void
     */
    public function __construct($email, $order)
    {
        $this->email = $email;
        $this->order = $order;
    }

    /**
     *Execute the job.
     */
    public function handle()
    {
        $subject = 'Payment failed for this order';
        $content = "test";
        Mail::send('email.paymentFailed', ['content' => $content], function ($message) use($subject)
        {
            $message->from('noreply@winds.co.in', 'Winds');

            $message->to($this->email);

            $message->subject($subject);

        });
    }
}
