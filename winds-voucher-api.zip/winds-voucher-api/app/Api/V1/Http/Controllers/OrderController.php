<?php

namespace App\Api\V1\Http\Controllers;

use DB;
use Exception;
use Throwable;
use App\Models\Order;
use App\Models\Denomination;
use Illuminate\Support\Facades\Auth;
use Winds\OrderHandler\Constants\OrderStatus;
use Winds\OrderHandler\Constants\ServiceType;
use App\Api\V1\Http\Resources\OrderCollection;
use App\Api\V1\Http\Requests\CreateOrderRequest;
use App\Jobs\SMSNotification\SendFulfillmentSMS;
use App\Api\V1\Http\Requests\ProcessOrderRequest;
use App\Jobs\SMSNotification\SendPaymentFailedSMS;
use App\Jobs\EmailNotification\SendFulfillmentEmail;
use App\Api\V1\Http\Resources\Order as OrderResource;
use App\Api\V1\Http\Controllers\Traits\CreatesOrders;
use App\Jobs\EmailNotification\SendPaymentFailedEmail;
use App\Jobs\SMSNotification\SendFulfillmentFailedSMS;
use App\Api\V1\Http\Controllers\Traits\ProcessesOrders;
use App\Jobs\EmailNotification\SendFulfillmentFailedEmail;

class OrderController extends ApiController
{
    use CreatesOrders, ProcessesOrders;

    /** @var \App\Models\User */
    protected $user;

    /**
     * List orders.
     *
     * @return \Illuminate\Http\JsonResponse
     * @throws Exception
     */
    public function index()
    {
        $this->user = $this->getLoggedInUser();

        $orderQuery = Order::where('user_id', $this->user->id)->latest();

        $vouchers = filter($orderQuery, OrderCollection::class)->paginate();

        return $this->respondOk($vouchers);
    }

    /**
     * Get the order details.
     *
     * @param Order $order
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function show(Order $order)
    {
        $this->authorize('view', $order);

        return $this->respondOk(new OrderResource($order));
    }

    /**
     * Create a new voucher order.
     *
     * @param CreateOrderRequest $request
     * @return \Illuminate\Http\JsonResponse
     * @throws Exception
     */
    public function store(CreateOrderRequest $request)
    {
        $this->user = $this->getLoggedInUser();

        $denominationId = $request->input('denomination_id');
        $quantity = $request->input('quantity');

        $denomination = Denomination::with('voucher')
            ->where('id', $denominationId)
            ->first();

        if (config('voucher.verify_voucher_pre_order')) {
            $this->validateVoucherAvailability($denomination);
        }

        $orderHandler = orderHandler();

        DB::beginTransaction();
        try {

            $order = $this->createOrder($request, $denomination, $quantity);

            $masterOrder = $orderHandler->createMasterOrder(
                $order,
                $this->user,
                ServiceType::VOUCHER,
                $order->net_payable_amount,
                $order->total_amount
            );

            $payment = $orderHandler->createPayment($order, $this->user, 'Voucher', $order->net_payable_amount);

            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();

            throw $e;
        }

        return $this->respondSuccess([
            'order_id' => $order->id,
            'payment_gateway_order_id' => $payment->gateway_order_id,
            'payment_amount' => round($order->net_payable_amount, 2),
        ]);
    }

    /**
     * Process and fulfill the voucher order.
     *
     * @param ProcessOrderRequest $request
     * @param mixed $orderId
     * @return \Illuminate\Http\JsonResponse
     * @throws Throwable
     */
    public function process(ProcessOrderRequest $request, $orderId)
    {
        $paymentFailedAtUserEnd = (bool) $request->get('payment_failed', false);

        $gatewayOrderId = $request->get('payment_gateway_order_id');

        $order = $this->fetchOrder($orderId);

        $masterOrder = $order->masterOrder;

        $payment = $this->fetchOrderPayment($order, $gatewayOrderId);

        $orderHandler = orderHandler();

        try {
            $orderHandler->processPayment($payment, $request->all(), $paymentFailedAtUserEnd);
        } catch (Throwable $e) {
            $this->updateOrderStatus($order, OrderStatus::PAYMENT_FAILED);
            $this->sendPaymentFailedNotification($order);
            throw $e;
        }

        $this->sendPaymentSuccessNotification($order);

        $this->updateOrderStatus($order, OrderStatus::PENDING_FULFILLMENT);

        $order->update(['paid_at' => now()]);

        $orderHandler->markMasterOrderAsPaid($masterOrder);

        try {
            $this->fulFillOrder($order);
        } catch (Throwable $e) {
            $this->updateOrderStatus($order, OrderStatus::FULFILLMENT_FAILED);
            $this->sendFulfillmentFailedNotification($order);
            throw $e;
        }

        $this->updateOrderStatus($order, OrderStatus::FULFILLED);

        $orderHandler->markMasterOrderAsFulfilled($masterOrder);

        $this->sendFulfillmentNotification($order);

        return $this->respondSuccess([
            'order_id' => $order->id
        ]);
    }

    /**
     * Handled notification when payment failed at customer end.
     *
     * @param $order
     */
    protected function sendPaymentFailedNotification($order)
    {
        if(Auth::User()->mobile){
            $this->sendPaymentFailedSMS(Auth::User()->mobile, $order);
        }
        if(Auth::User()->email) {
            $this->sendPaymentFailedEmail(Auth::User()->email, $order);
        }
    }

    /**
     * Handled notification when payment is successfully done but fulfillment is failed.
     *
     * @param $order
     */
    protected function sendFulfillmentFailedNotification($order)
    {
        if(Auth::User()->mobile) {
            $this->sendFulfillmentFailedSMS(Auth::User()->mobile, $order);
        }
        if(Auth::User()->email) {
            $this->sendFulfillmentFailedEmail(Auth::User()->email, $order);
        }
    }

    /**
     * Handled notification when fulfillment successfully complete.
     *
     * @param $order
     */
    protected function sendFulfillmentNotification($order)
    {
        if(Auth::User()->mobile) {
            $this->sendFulfillmentSMS(Auth::User()->mobile, $order);
        }
        if(Auth::User()->email) {
            $this->sendFulfillmentEmail(Auth::User()->email, $order);
        }
    }

    /**
     * Send sms if payment failed at user end.
     *
     * @param $order
     * @param $number
     */
    protected function sendPaymentFailedSMS($number, $order)
    {
        try {
            dispatch(new SendPaymentFailedSMS($number, $order));
        } catch (Exception $e) {
            log_exception($e);
        }
    }

    /**
     * Send email if payment is failed at user end.
     *
     * @param $email
     * @param $order
     */
    protected function sendPaymentFailedEmail($email, $order)
    {
        try {
            dispatch(new SendPaymentFailedEmail($email, $order));
        } catch (Exception $e) {
            log_exception($e);
        }
    }

    /**
     * Send sms when fulfillment failed from gci services.
     *
     * @param $number
     * @param $order
     */
    protected function sendFulfillmentFailedSMS($number, $order)
    {
        try {
            dispatch(new SendFulfillmentFailedSMS($number, $order));
        } catch (Exception $e) {
            log_exception($e);
        }
    }

    /**
     * Send mail when fulfillment failed from gci services.
     *
     * @param $email
     * @param $order
     */
    protected function sendFulfillmentFailedEmail($email, $order)
    {
        try {
            dispatch(new SendFulfillmentFailedEmail($email, $order));
        } catch (Exception $e) {
            log_exception($e);
        }
    }

    protected function sendPaymentSuccessNotification($order)
    {
        if(Auth::User()->mobile) {
            try {
                $message = "Thank you for shopping through WINDS! Transaction with Txn ID: ".$order->transaction_id." for your online purchase worth Rs. ".$order->net_payable_amount." has been processed.";
                sms()->to(Auth::User()->mobile)->message($message)->transactional()->send();
            } catch (Exception $e) {
                log_exception($e);
            }
        }
    }

    /**
     * Send sms when fulfillment successfully complete.
     *
     * @param $number
     * @param $order
     */
    protected function sendFulfillmentSMS($number, $order)
    {
        try {
            dispatch(new SendFulfillmentSMS($number, $order));
        } catch (Exception $e) {
            log_exception($e);
        }
    }

    /**
     * Send mail when fulfillment successfully complete
     *
     * @param $email
     * @param $order
     */
    protected function sendFulfillmentEmail($email, $order)
    {
        try {
            dispatch(new SendFulfillmentEmail($email, $order));
        } catch (Exception $e) {
            log_exception($e);
        }
    }
}
