<?php

namespace App\Api\V1\Http\Controllers;

use Exception;

class WalletController extends ApiController
{
    /**
     * Get the GCI wallet balance.
     *
     * @return \Illuminate\Http\JsonResponse
     * @throws Exception
     */
    public function balance()
    {
        $balance = null;

        try {
            $result = gci()->getAccessToken();

            $accessToken = $result['accessToken'];

            $result = gci()->getPartnerBalance($accessToken);

            $balance = round($result['balance'], 2);

        } catch (Exception $e) {
            log_exception($e);

            throw new Exception('Unable to fetch the GCI wallet balance.');
        }

        return $this->respondOk(compact('balance'));
    }
}
