<?php

namespace App\Api\V1\Http\Controllers;

use App\Models\Denomination;
use App\Winds\Services\Cart\Cart;
use App\Api\V1\Http\Requests\CartDetailRequest;

class ShoppingCartController extends ApiController
{
    /**
     * Get the card details.
     *
     * @param CartDetailRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function details(CartDetailRequest $request)
    {
        $denominationId = $request->input('denomination_id');
        $quantity = $request->input('quantity');

        $denomination = Denomination::where('id', $denominationId)->first();

        $cart = new Cart($denomination->value, $quantity);

        return $this->respondSuccess([
            [
                'key' => 'Total Vouchers',
                'value' => $cart->getQuantity()
            ],
            [
                'key' => 'Item Total',
                'value' => display_rupees($cart->getItemTotal())
            ],
            [
                'key' => 'Delivery Fee',
                'value' => display_rupees(0)],
            [
                'key' => 'PG Charge',
                'value' => display_rupees($cart->getPaymentGatewayCharge())
            ],
            [
                'key' => 'To Pay',
                'value' => display_rupees($cart->getTotal())
            ],
        ]);
    }
}
