<?php

namespace App\Api\V1\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Helpers\Response\ResponseHelpers;

abstract class ApiController extends Controller
{
    use ResponseHelpers;

    /**
     * Get the currently logged in user.
     *
     * @return \App\Models\User|null
     */
    protected function getLoggedInUser()
    {
        return auth()->user();
    }
}
