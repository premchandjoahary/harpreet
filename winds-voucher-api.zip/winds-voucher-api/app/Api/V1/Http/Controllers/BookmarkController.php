<?php

namespace App\Api\V1\Http\Controllers;

use App\Models\Voucher;

class BookmarkController extends ApiController
{
    /**
     * Bookmark a voucher.
     *
     * @param Voucher $voucher
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Voucher $voucher)
    {
        $user = $this->getLoggedInUser();

        $voucher->bookmarkedUsers()->syncWithoutDetaching($user);

        return $this->respondSuccess();
    }

    /**
     * Remove voucher bookmark.
     *
     * @param Voucher $voucher
     * @return \Illuminate\Http\JsonResponse
     */
    public function delete(Voucher $voucher)
    {
        $user = $this->getLoggedInUser();

        $voucher->bookmarkedUsers()->detach($user);

        return $this->respondSuccess();
    }
}
