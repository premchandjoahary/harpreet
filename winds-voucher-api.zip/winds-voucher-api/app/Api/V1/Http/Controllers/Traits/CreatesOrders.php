<?php

namespace App\Api\V1\Http\Controllers\Traits;

use Log;
use Bugsnag;
use Exception;
use App\Models\Order;
use App\Models\Address;
use App\Models\UserAddress;
use App\Models\Denomination;
use Illuminate\Http\Request;
use App\Winds\Services\Cart\Cart;
use Winds\OrderHandler\Constants\OrderStatus;

trait CreatesOrders
{
    /**
     * Create the voucher order.
     *
     * @param Request $request
     * @param Denomination $denomination
     * @param int $quantity
     * @return Order
     */
    protected function createOrder(Request $request, Denomination $denomination, $quantity)
    {
        $cart = new Cart($denomination->value, $quantity);

        $billingAddressId = $this->saveAddress($request, 'billing_');

        $shippingAddressId = (bool) $request->input('shipping_same_as_billing', false)
            ? null
            : $this->saveAddress($request, 'shipping_');

        $voucher = $denomination->voucher;

        return Order::create([
            'transaction_id' => $this->generateTransactionId(),
            'status' => OrderStatus::PENDING_PAYMENT,
            'user_id' => $this->user->id,
            'voucher_id' => $voucher->id,
            'denomination_id' => $denomination->id,
            'quantity' => $cart->getQuantity(),
            'denomination_value' => $cart->getItemAmount(),
            'total_amount' => $cart->getItemTotal(),
            'pg_amount' => $cart->getPaymentGatewayCharge(),
            'net_payable_amount' => $cart->getTotal(),
            'billing_address_id' => $billingAddressId,
            'shipping_address_id' => $shippingAddressId,
            'offer_percentage' => $voucher->offer_percentage,
            'delivery_type' => $voucher->delivery_type,
            'ip' => ip()
        ]);
    }

    /**
     * Save the order address and return the address id.
     *
     * @param Request $request
     * @param string $prefix
     * @return mixed
     */
    protected function saveAddress(Request $request, $prefix = 'billing_')
    {
        $userAddressId = $request->input("{$prefix}address_id");

        $userAddress = UserAddress::where('id', $userAddressId)
            ->where('user_id', auth()->id())
            ->first();

        $address = Address::create([
            'name' => $request->input("{$prefix}name"),
            'email' => $request->input("{$prefix}email"),
            'mobile' => $request->input("{$prefix}mobile"),
            'address' => $this->buildAddressText($userAddress),
            'city' => $userAddress->city,
            'state' => $userAddress->state,
            'zip' => $userAddress->pincode
        ]);

        return $address->id;
    }

    /**
     * Build the address text given the user address object.
     *
     * @param UserAddress $address
     * @return string
     */
    protected function buildAddressText(UserAddress $address)
    {
        $addressText = $address->house_details;

        if ($address->landmark) {
            $addressText .= ", {$address->landmark}";
        }

        $addressText .= ", {$address->street},  {$address->area}";

        return $addressText;
    }

    /**
     * Generate a unique transaction id.
     *
     * @return string
     */
    protected function generateTransactionId()
    {
        return substr(hash('sha256', mt_rand() . microtime()), 0, 20);
    }

    /**
     * Validate if the voucher is currently available for purchase on GCI.
     *
     * @param Denomination $denomination
     * @throws Exception
     */
    protected function validateVoucherAvailability(Denomination $denomination)
    {
        try {
            $result = gci()->getAccessToken();

            $accessToken = $result['accessToken'];

            $result = gci()->getDenominations($accessToken, $denomination->voucher->hash);

            $denominations = collect($result['denominations']);

            if (! $denominations->contains('skuId', $denomination->sku_id)) {
                throw new Exception('The sku id of the order denomination is not available in the GCI API response.');
            }

        } catch (Exception $e) {
            Log::error($e);

            Bugsnag::notifyException($e);

            throw new Exception('The voucher is currently unavailable. Please refresh or try again later.');
        }
    }
}
