<?php

namespace App\Api\V1\Http\Controllers\Traits;

use Log;
use Bugsnag;
use Exception;
use App\Models\Order;
use App\Models\GciOrder;
use App\Winds\Constants\GCIOrderStatus;
use Winds\OrderHandler\Constants\OrderStatus;
use Winds\OrderHandler\Constants\PaymentStatus;

trait ProcessesOrders
{
    /**
     * Fulfill the voucher order with GCI.
     *
     * @param Order $order
     * @return GciOrder
     * @throws Exception
     */
    protected function fulFillOrder(Order $order)
    {
        $gciOrderData = $this->getGCIOrderData($order);

        $gciOrder = null;
        $gciOrderResponse = null;
        $gciOrderReceipt = null;

        try {
            $gciOrder = GciOrder::create([
                'order_id' => $order->id,
                'status' => GCIOrderStatus::INITIATED,
                'request' => $gciOrderData
            ]);

            $result = gci()->getAccessToken();

            $accessToken = $result['accessToken'];

            $gciOrderResponse = gci()->createOrder($accessToken, $gciOrderData);

            if (! isset($gciOrderResponse['receipt'])) {
                throw new Exception('The GCI order add API returned an invalid response.');
            }

            $gciOrderReceipt = $gciOrderResponse['receipt'];

            $gciOrder->update([
                'status' => GCIOrderStatus::SUCCESS,
                'receipt' => $gciOrderReceipt,
                'response' => $gciOrderResponse,
            ]);

        } catch (Exception $e) {

            if ($gciOrder) {
                $gciOrder->update([
                    'status' => GCIOrderStatus::FAILED,
                    'response' => $gciOrderResponse,
                    'error_message' => str_limit($e->getMessage(), 255),
                ]);
            }

            Log::error($e);

            Bugsnag::notifyException($e);

            throw new Exception('Unable to fulfill the order. Please try again later. Any payment made will be refunded back.');
        }

        return $gciOrder;
    }

    /**
     * Get the GCI order data.
     *
     * @param Order $order
     * @return array
     */
    protected function getGCIOrderData(Order $order)
    {
        $billingAddress = $order->billingAddress;
        $shippingAddress = $order->shippingAddress ?? $billingAddress;

        return [
            'skuId' => $order->denomination->sku_id,
            'lineItemQuantity' => (int) $order->quantity,
            'clientOrderId' => 'Winds-' . time() . '-' . $order->id,
            'orderDate' => $order->created_at->format('d/m/Y'),
            'paymentMode' => 'Prepaid',
            'paymentStatus' => 'Payment Received',

            'billingName' => $billingAddress->name,
            'billingEmail' => $billingAddress->email,
            'billingMobile' => $billingAddress->mobile,
            'billingAddressLine1' => $billingAddress->address,
            'billingCity' => $billingAddress->city,
            'billingState' => $billingAddress->state,
            'billingCountry' => 'India',
            'billingZip' => $billingAddress->zip,

            'receiversName' => $shippingAddress->name,
            'receiversEmail' => $shippingAddress->email,
            'shippingMobile' => $shippingAddress->mobile,
            'shippingAddressLine1' => $shippingAddress->address,
            'shippingCity' => $shippingAddress->city,
            'shippingState' => $shippingAddress->state,
            'shippingCountry' => 'India',
            'shippingZip' => $shippingAddress->zip,
        ];
    }

    /**
     * Update the order and master order status.
     *
     * @param Order $order
     * @param int $status
     */
    protected function updateOrderStatus(Order $order, $status)
    {
        $order->update([
            'status' => $status
        ]);

        $order->masterOrder()->update([
            'status' => $status
        ]);
    }

    /**
     * Fetch the voucher order.
     *
     * @param $orderId
     * @return Order
     */
    protected function fetchOrder($orderId)
    {
        $order = Order::where('id', $orderId)
            ->where('user_id', auth()->id())
            ->first();

        if (! $order) {
            abort(404, 'Order not found');
        }

        if ($order->status !== OrderStatus::PENDING_PAYMENT) {
            abort(403, 'The order has already been processed');
        }

        return $order;
    }

    /**
     * Fetch the payment for the order using gateway order id.
     *
     * @param Order $order
     * @param string $gatewayOrderId
     * @return \Winds\OrderHandler\Models\Payment
     */
    protected function fetchOrderPayment(Order $order, $gatewayOrderId)
    {
        $payment = $order->payments()
            ->where('gateway_order_id', $gatewayOrderId)
            ->first();

        if (! $payment) {
            abort(404, 'Payment not found for this order');
        }

        if ($payment->status !== PaymentStatus::INITIATED) {
            abort(403, 'The payment for this order has already been processed');
        }

        return $payment;
    }
}
