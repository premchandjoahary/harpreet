<?php

namespace App\Api\V1\Http\Controllers;

class HomeController extends ApiController
{
    /**
     * Get the application home route response.
     *
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function index()
    {
        return $this->respondOk([
            'status' => 'All good!'
        ]);
    }
}
