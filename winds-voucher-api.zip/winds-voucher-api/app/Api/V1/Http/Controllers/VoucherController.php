<?php

namespace App\Api\V1\Http\Controllers;

use DB;
use Exception;
use Throwable;
use App\Models\Order;
use App\Models\Voucher;
use App\Models\Category;
use App\Api\V1\Filters\VoucherFilter;
use Illuminate\Database\Eloquent\Builder;
use Winds\OrderHandler\Constants\OrderStatus;
use App\Api\V1\Http\Resources\VoucherInfoCollection;
use App\Api\V1\Http\Resources\Voucher as VoucherResource;
use App\Api\V1\Http\Resources\VoucherCodeCollection as VoucherCodeResource;

class VoucherController extends ApiController
{
    /**
     * List vouchers.
     *
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function index()
    {
        /*
         * Null values show up first when sorting by sort order and if new vouchers get added
         * which doesn't have sort order defined. So we use the negative desc sorting strategy
         * to push the items with sort order first and push null values to bottom.
         */
        $voucherQuery = Voucher::whereHas('denominations')
            ->published()
            ->orderByDesc(DB::raw('-sort_order'))
            ->orderBy('name');

        return $this->getVouchers($voucherQuery, true);
    }

    /**
     * List vouchers by popularity.
     *
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function popular()
    {
        $voucherQuery = Voucher::whereHas('denominations')
            ->published()
            ->orderByDesc('view_count')
            ->orderBy('name');

        return $this->getVouchers($voucherQuery, true);
    }

    /**
     * List bookmarked vouchers.
     *
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function bookmarked()
    {
        $user = $this->getLoggedInUser();

        $voucherQuery = Voucher::whereHas('denominations')
            // Add custom select to spoof bookmark field as true without querying db.
            ->selectRaw('*, 1 as bookmarked_users_count')
            ->whereHas('bookmarkedUsers', function (Builder $query) use ($user) {
                $query->where('user_id', $user->id);
            })
            ->published()
            ->orderBy('name');

        return $this->getVouchers($voucherQuery);
    }

    /**
     * Get the voucher details.
     *
     * @param $voucherId
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($voucherId)
    {
        $voucher = Voucher::where('id', $voucherId)
            ->loadBookmarkCount()
            ->firstOrFail();

        return $this->respondOk(new VoucherResource($voucher));
    }

    /**
     * Get all the voucher filter data.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function filters()
    {
        $categories = Category::select('id as key', 'name as value')
            ->orderBy('name')
            ->get()
            ->toArray();

//        $types = [
//            ['key' => 'Digital', 'value' => 'Digital'],
//            ['key' => 'Instant', 'value' => 'Instant'],
//        ];

        return $this->respondOk([
//            'type' => $types,
            'segment' => $categories,
        ]);
    }

    /**
     * Get the vouchers.
     *
     * @param Builder $query
     * @param bool $withBookmarkCount
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    protected function getVouchers(Builder $query, $withBookmarkCount = false)
    {
        // If the bookmark count is required then load the count relationship.
        if ($withBookmarkCount) {
            $query->loadBookmarkCount();
        }

        $vouchers = filter($query, VoucherInfoCollection::class, VoucherFilter::class)->paginate();

        return $this->respondOk($vouchers);
    }

    /**
     * @param Order $order
     * @return \Illuminate\Http\JsonResponse
     * @throws Exception
     */
    public function voucherCode(Order $order)
    {
        $this->checkVoucherCodeAvailability($order);

        DB::beginTransaction();
        try {
            $receipt = $order->gciOrder->receipt;

            $result = gci()->getAccessToken();
            $accessToken = $result['accessToken'];
            $result = gci()->getVoucherCode($accessToken, $receipt);

            $order->update([
                'voucher_code_generated' => true
            ]);

            DB::commit();

            $voucherCodeCollection = collect($result);

            return $this->respondOk(new VoucherCodeResource($voucherCodeCollection));

        } catch (Exception $e) {
            DB::rollBack();

            log_exception($e);

            abort(404, 'Voucher code for this order is not available at this moment.');
        }
    }

    /**
     * @param Order $order
     * @throws Exception
     */
    protected function checkVoucherCodeAvailability(Order $order)
    {
        if(!$order->paid_at) {
            abort(404, 'The payment is incomplete for this order');
        }

        if($order->status != OrderStatus::FULFILLED) {
            abort(404, 'This order is not fulfilled.');
        }

        if(!isset($order->gciOrder->receipt)) {
            abort(404, 'The order fulfillment receipt is not available.');
        }

        return;
    }
}
