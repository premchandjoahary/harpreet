<?php

namespace App\Api\V1\Http\Resources;

use Winds\OrderHandler\Constants\OrderStatus;
use Illuminate\Http\Resources\Json\JsonResource;

class Order extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        $masterOrder = $this->masterOrder;

        return [
            'id' => $this->id,
            'order_number' => "#{$masterOrder->id}",
            'service' => 'voucher',
            'voucher_name' => $this->voucher->name,
            'voucher_image' => $this->voucher->app_image_url,
            'web_image_url' => $this->voucher->web_image_url,
            'amount' => round($masterOrder->amount, 2),
            'status' => $masterOrder->status,
            'statusText' => $this->getStatusText(),
            'payment_failed' => (int) $masterOrder->status === OrderStatus::PAYMENT_FAILED,
            'voucher_code_generated' => (boolean) $this->voucher_code_generated,
            'wrp' => (int) $masterOrder->wrp,
            'wrp_credited' => $masterOrder->wrp_credited_at !== null,
            'fulfilled' => $masterOrder->fulfilled_at !== null,
            'created_at' => $masterOrder->created_at->format('d M Y, h:i a')
        ];
    }
}
