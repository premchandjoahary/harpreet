<?php

namespace App\Api\V1\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class VoucherCode extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'voucher_number' => data_get($this, 'voucherNumber'),
            'voucher_pin' => data_get($this, 'voucherPin') === 'NA' ? null : data_get($this, 'voucherPin'),
            'expiry_date' => data_get($this, 'expiryDate'),
        ];
    }
}
