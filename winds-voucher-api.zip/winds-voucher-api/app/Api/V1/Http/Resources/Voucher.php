<?php

namespace App\Api\V1\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class Voucher extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'hash' => $this->hash,
            'name' => $this->name,
            'image_url' => $this->app_image_url, // Custom attribute
            'web_image_url' => $this->web_image_url, // Custom attribute
            'winds_rating' => $this->winds_rating, // Custom attribute
            'delivery_type' => $this->delivery_type,
            'turn_around_time_in_days' => (int) ($this->turn_around_time / 24),
            'bookmarked' => (bool) $this->bookmarked_users_count,
            'website' => $this->website,
            'description' => $this->description,
            'terms' => $this->terms,
            'categories' => Category::collection($this->categories),
            'denominations' => Denomination::collection($this->denominations),
        ];
    }
}
