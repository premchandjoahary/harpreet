<?php

namespace App\Api\V1\Http\Requests;

class CartDetailRequest extends BaseRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'denomination_id' => 'required|exists:denominations,id',
            'quantity' => 'required|integer|min:1|max:25'
        ];
    }

    /**
     * Get custom attributes for validator errors.
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'denomination_id' => 'denomination'
        ];
    }
}
