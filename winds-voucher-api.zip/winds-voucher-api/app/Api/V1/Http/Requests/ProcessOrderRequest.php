<?php

namespace App\Api\V1\Http\Requests;

class ProcessOrderRequest extends BaseRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'payment_failed' => 'boolean',
            'payment_gateway_order_id' => 'required',
        ];
    }
}
