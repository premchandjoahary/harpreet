<?php

namespace App\Api\V1\Http\Requests;

use App\Models\UserAddress;
use App\Models\Denomination;
use Illuminate\Validation\Validator;

class CreateOrderRequest extends BaseRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'denomination_id' => 'required|integer',
            'quantity' => 'required|integer|min:1',
            'billing_name' => 'required|min:3|max:60',
            'billing_email' => 'required|email|max:128',
            'billing_mobile' => 'required|regex:/^[0-9]{10}+$/',
            'billing_address_id' => 'required|integer',
            'shipping_same_as_billing' => 'required|boolean',
        ];

        if (! (bool) $this->get('shipping_same_as_billing', false)) {
            $rules = array_merge($rules, [
                'shipping_name' => 'required|min:3|max:60',
                'shipping_email' => 'required|email|max:128',
                'shipping_mobile' => 'required|regex:/^[0-9]{10}+$/',
                'shipping_address_id' => 'required|integer',
            ]);
        }

        return $rules;
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'billing_mobile.regex' => 'The :attribute is invalid.',
            'shipping_mobile.regex' => 'The :attribute is invalid.',
        ];
    }

    /**
     * Get custom attributes for validator errors.
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'denomination_id' => 'voucher',
            'billing_mobile' => 'billing mobile number',
            'billing_address_id' => 'billing address',
            'shipping_mobile' => 'shipping mobile number',
            'shipping_address_id' => 'shipping address',
        ];
    }

    /**
     * Configure the validator instance.
     *
     * @param Validator $validator
     * @return void
     */
    public function withValidator(Validator $validator)
    {
        $validator->after(function (Validator $validator) {

            $this->validateDenomination($validator, 'denomination_id');

            $this->validateAddresses($validator);
        });
    }

    /**
     * Validate if the voucher and the denomination are enabled.
     *
     * @param Validator $validator
     * @param string $field
     */
    protected function validateDenomination(Validator $validator, $field)
    {
        $denominationId = $this->get($field);

        $denomination = Denomination::where('id', $denominationId)->first();

        if (! $denomination) {
            $validator->errors()->add($field, 'The selected voucher is invalid.');
            return;
        }

        if (! $denomination->voucher->active || ! $denomination->voucher->enabled_by_provider) {
            $validator->errors()->add($field, 'The selected voucher is disabled.');
            return;
        }

        if (! $denomination->active || ! $denomination->enabled_by_provider) {
            $validator->errors()->add($field, 'The selected voucher denomination is disabled.');
            return;
        }
    }

    /**
     * Validate the billing and shipping addresses.
     *
     * @param Validator $validator
     */
    protected function validateAddresses(Validator $validator)
    {
        $this->validateAddress($validator, 'billing_address_id');

        if ((bool) $this->get('shipping_same_as_billing', false) || ! $this->get('shipping_address_id')) {
            return;
        }

        $this->validateAddress($validator, 'shipping_address_id');
    }

    /**
     * Validate the address.
     *
     * @param Validator $validator
     * @param string $field
     */
    protected function validateAddress(Validator $validator, $field)
    {
        $addressId = $this->get($field);

        $addressExists = UserAddress::where('id', $addressId)
            ->where('user_id', auth()->id())
            ->exists();

        if (! $addressExists) {
            $validator->errors()->add($field, 'The selected address is invalid.');
            return;
        }
    }
}
