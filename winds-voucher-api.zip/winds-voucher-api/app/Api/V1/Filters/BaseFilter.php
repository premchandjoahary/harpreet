<?php

namespace App\Api\V1\Filters;

use Exception;
use Validator;
use Carbon\Carbon;
use App\Winds\Libraries\QueryFilter\FilterContract;

abstract class BaseFilter implements FilterContract
{
    /**
     * Apply the created from filter.
     *
     * @param \Illuminate\Database\Eloquent\Builder $builder
     * @param string|null $fromDate
     * @throws \Exception
     */
    public function created_from($builder, $fromDate = null)
    {
        $date = $this->validateDate($fromDate, 'created from date');

        $builder->whereDate('created_at', '>=', $date);
    }

    /**
     * Apply the created to filter.
     *
     * @param \Illuminate\Database\Eloquent\Builder $builder
     * @param string|null $toDate
     * @throws \Exception
     */
    public function created_to($builder, $toDate = null)
    {
        $date = $this->validateDate($toDate, 'created to date');

        $builder->whereDate('created_at', '<=', $date);
    }

    /**
     * Validates date time string.
     * Returns the Carbon instance of the date if valid.
     *
     * @param string $date
     * @param string $field
     * @return \Carbon\Carbon
     * @throws \Exception
     */
    protected function validateDateTime($date, $field = 'date')
    {
        if (Validator::make(['date' => $date], ['date' => 'required|date'])->fails()) {
            throw new Exception("Invalid {$field}.");
        }

        return Carbon::parse($date);
    }

    /**
     * Validates date string.
     * Returns the Carbon instance of the date (Resets the time to 00:00:00) if valid.
     *
     * @param string $date
     * @param string $field
     * @return \Carbon\Carbon
     * @throws \Exception
     */
    protected function validateDate($date, $field = 'date')
    {
        return $this->validateDateTime($date, $field)->startOfDay();
    }

    /**
     * Resolves a string to boolean value.
     *
     * @param string $value
     * @return bool
     */
    protected function resolveBoolean(string $value)
    {
        return filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }
}
