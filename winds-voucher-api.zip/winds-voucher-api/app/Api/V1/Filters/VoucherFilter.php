<?php

namespace App\Api\V1\Filters;

use Illuminate\Database\Eloquent\Builder;

class VoucherFilter extends BaseFilter
{
    /**
     * The available filters.
     *
     * @return array
     */
    public function filters()
    {
        return [
//            'type', 'delivery'
            'segment'
        ];
    }

    /**
     * Apply voucher type filter.
     *
     * @param Builder $builder
     * @param mixed|null $type
     */
//    public function type(Builder $builder, $type = null)
//    {
//        if ($type === null) {
//            return;
//        }
//
//        $deliveryTypes = array_filter(array_map('trim', explode(',', $type)));
//
//        $builder->whereIn('delivery_type', $deliveryTypes);
//    }

    /**
     * Apply voucher segment filter.
     *
     * @param Builder $builder
     * @param mixed|null $segment
     */
    public function segment(Builder $builder, $segment = null)
    {
        if ($segment === null) {
            return;
        }

        $categories = array_filter(explode(',', $segment));

        $builder->whereHas('categories', function ($query) use ($categories) {
            $query->whereIn('category_id', $categories);
        });
    }

    /**
     * Apply voucher delivery filter.
     *
     * @param Builder $builder
     * @param mixed|null $delivery
     */
//    public function delivery(Builder $builder, $delivery = null)
//    {
//        if ($delivery === null) {
//            return;
//        }
//
//        $minDeliveryTime = (int) $delivery * 24;
//
//        $builder->where('turn_around_time', '<=', $minDeliveryTime);
//    }
}
