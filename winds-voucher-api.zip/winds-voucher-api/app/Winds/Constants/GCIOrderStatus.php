<?php

namespace App\Winds\Constants;

class GCIOrderStatus
{
    const INITIATED = 0;
    const SUCCESS   = 1;
    const FAILED    = 2;
}
