<?php

namespace App\Winds\Services\Cart;

class Cart
{
    /** @var float|double */
    protected $itemAmount;
    /** @var int */
    protected $quantity;
    /** @var float|double */
    protected $itemTotal;
    /** @var float|double */
    protected $paymentGatewayChargeRate;
    /** @var float|double */
    protected $paymentGatewayCharge;
    /** @var float|double */
    protected $total;

    /**
     * Cart constructor.
     *
     * @param float|double $itemAmount
     * @param int $quantity
     */
    public function __construct($itemAmount, $quantity)
    {
        $this->itemAmount = round($itemAmount, 2);

        $this->quantity = (int) $quantity;

        $this->itemTotal = round($this->itemAmount * $quantity, 2);

        $this->paymentGatewayChargeRate = round(config('voucher.payment_gateway_charge_rate'), 2);

        $this->paymentGatewayCharge = round(($this->itemTotal * $this->paymentGatewayChargeRate) / 100, 2);

        $this->total = round($this->itemTotal + $this->paymentGatewayCharge, 2);
    }

    /**
     * Get individual item amount.
     *
     * @return float
     */
    public function getItemAmount()
    {
        return $this->itemAmount;
    }

    /**
     * Get the item quantity.
     *
     * @return int
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     * Get the total item amount.
     *
     * @return float
     */
    public function getItemTotal()
    {
        return $this->itemTotal;
    }

    /**
     * Get the payment gateway charge percentage.
     *
     * @return float
     */
    public function getPaymentGatewayChargeRate()
    {
        return $this->paymentGatewayChargeRate;
    }

    /**
     * Get the payment gateway charge amount.
     *
     * @return float
     */
    public function getPaymentGatewayCharge()
    {
        return $this->paymentGatewayCharge;
    }

    /**
     * Get the total payable amount.
     *
     * @return float
     */
    public function getTotal()
    {
        return $this->total;
    }
}
