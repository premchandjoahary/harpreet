<?php

namespace App\Winds\Libraries\QueryFilter;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Config\Repository as ConfigRepository;
use Illuminate\Http\Resources\Json\JsonResource;

class QueryFilter implements QueryFilterContract
{
    /**
     * The delimiter used to separate the fields.
     *
     * @var string
     */
    const DELIMITER = ',';

    /**
     * The default filters.
     *
     * @var array
     */
    protected $defaultFilters = [
        'sort',
        'limit'
    ];

    /**
     * The config array.
     *
     * @var array
     */
    protected $config;

    /**
     * The Request object.
     *
     * @var \Illuminate\Http\Request
     */
    protected $request;

    /**
     * The Eloquent Query Builder instance.
     *
     * @var \Illuminate\Database\Eloquent\Builder|null
     */
    protected $builder = null;

    /**
     * The custom filter class instance.
     *
     * @var \App\Winds\Libraries\QueryFilter\FilterContract|null
     */
    protected $customFilter = null;

    /**
     * The query builder model.
     *
     * @var \Illuminate\Database\Eloquent\Model|null
     */
    protected $model = null;

    /**
     * The default (pagination) result limit.
     *
     * @var int|null
     */
    protected $defaultLimit = null;

    /**
     * The api resource or resource collection.
     *
     * @var string|null
     */
    protected $resource = null;

    /**
     * The default sort value if none are provided.
     *
     * @var string|null
     */
    protected $defaultSort = null;

    /**
     * The additional data to be added to the response.
     *
     * @var array
     */
    protected $additional = [];

    /**
     * The minimum (pagination) result limit.
     *
     * @var int|null
     */
    protected $minLimit = null;

    /**
     * The maximum (pagination) result limit.
     *
     * @var int|null
     */
    protected $maxLimit = null;

    /**
     * The default (pagination) result limit.
     *
     * @var int|null
     */
    protected $limit = null;

    /**
     * Enable pagination on the filter.
     *
     * @var boolean
     */
    protected $paginate = false;

    /**
     * QueryFilter constructor.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Illuminate\Config\Repository $config
     */
    public function __construct(Request $request, ConfigRepository $config)
    {
        $this->config = $config['filters'];
        $this->request = $request;

        $this->defaultLimit = $this->config('limit.default', 10);
        $this->minLimit = $this->config('limit.min', 5);
        $this->maxLimit = $this->config('limit.max', 50);

        $this->limit = $this->defaultLimit;
    }

    /**
     * Set the Query Builder.
     *
     * @param \Illuminate\Database\Eloquent\Builder $builder
     * @return $this
     */
    public function builder($builder)
    {
        $this->builder = $builder;

        return $this;
    }

    /**
     * Set the custom filter.
     *
     * @param \App\Winds\Libraries\QueryFilter\FilterContract|string $filter
     * @return $this
     * @throws \Exception
     */
    public function customFilter($filter)
    {
        if (is_string($filter) && ! class_exists($filter)) {
            throw new Exception('Invalid filter class ' . $filter);
        }

        $filter = new $filter;

        if (! $filter instanceof FilterContract) {
            throw new Exception('Invalid filter class ' . get_class($filter));
        }

        $this->customFilter = $filter;

        return $this;
    }

    /**
     * Set the resource or resource collection to be used for data transformation.
     * Setting the resource enables the data transformation.
     *
     * @param \Illuminate\Http\Resources\Json\JsonResource|\Illuminate\Http\Resources\Json\ResourceCollection $resource
     * @return $this
     */
    public function transformWith($resource)
    {
        $this->resource = $resource;

        return $this;
    }

    /**
     * Set the default sort order if none are provided in the query string.
     *
     * @param string $sort
     * @return $this
     */
    public function defaultSort($sort)
    {
        if (is_string($sort)) {
            $this->defaultSort = $sort;
        }

        return $this;
    }

    /**
     * Set the additional data to be added to the response.
     *
     * @param array $additional
     * @return $this
     */
    public function additionalData(array $additional)
    {
        $this->additional = $additional;

        return $this;
    }

    /**
     * Apply the filters and get the result.
     *
     * @param array $columns
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator|\Illuminate\Database\Eloquent\Collection|\Illuminate\Database\Eloquent\Model|\Illuminate\Http\Resources\Json\JsonResource|\Illuminate\Http\Resources\Json\ResourceCollection|null
     * @throws \Exception
     */
    public function get($columns = ['*'])
    {
        if ($this->paginate) {
            return $this->paginate($columns);
        }

        $data = $this->applyFilters()->get($columns);

        return $this->transformData($data);
    }

    /**
     * Apply the filters and paginate the result.
     *
     * @param array $columns
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator|\Illuminate\Http\Resources\Json\ResourceCollection|null
     * @throws \Exception
     */
    public function paginate($columns = ['*'])
    {
        $this->paginate = true;

        $data = $this->applyFilters()
            ->paginate($this->limit, $columns)
            ->appends($this->request->query());

        return $this->transformData($data);
    }

    /**
     * Apply transformation to the provided data.
     *
     * @param mixed $data
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator|\Illuminate\Database\Eloquent\Collection|\Illuminate\Database\Eloquent\Model|\Illuminate\Http\Resources\Json\JsonResource|\Illuminate\Http\Resources\Json\ResourceCollection|null
     * @throws \Exception
     */
    protected function transformData($data)
    {
        if ($this->resource === null) {
            return $data;
        }

        if (! is_subclass_of($this->resource, JsonResource::class)) {
            throw new Exception("Invalid resource class provided {$this->resource}");
        }

        /** @var JsonResource $resource */
        $resource = new $this->resource($data);

        return $resource->additional(array_merge(['success' => true], $this->additional));
    }

    /**
     * Apply all the requested filters that are available.
     *
     * @return \Illuminate\Database\Eloquent\Builder
     * @throws \Exception
     */
    protected function applyFilters()
    {
        if ($this->builder === null) {
            throw new Exception('Query builder not set for filtering.');
        }

        $this->model = $this->builder->getModel();

        /*
         * Apply the default filters.
         */
        foreach ($this->getFilters() as $name => $value) {
            $name = 'filter' . studly_case($name);
            if (method_exists($this, $name)) {
                $value !== null
                    ? $this->$name($value)
                    : $this->$name();
            }
        }

        /*
         * Apply the custom filters.
         */
        foreach ($this->getCustomFilters() as $name => $value) {
            if (method_exists($this->customFilter, $name)) {
                $value !== null
                    ? $this->customFilter->$name($this->builder, $value)
                    : $this->customFilter->$name($this->builder);
            }
        }

        return $this->builder;
    }

    /**
     * Get all the filters that can be applied.
     *
     * @return array
     */
    protected function getFilters()
    {
        return $this->getAvailableFilters($this->defaultFilters);
    }

    /**
     * Get all the filters that can be applied.
     *
     * @return array
     */
    protected function getCustomFilters()
    {
        if ($this->customFilter === null) {
            return [];
        }

        return $this->getAvailableFilters($this->customFilter->filters());
    }

    /**
     * Get the available filters from the requested filters.
     *
     * @param array $filters
     * @return array
     */
    protected function getAvailableFilters(array $filters)
    {
        $queryParams = $this->request->query();

        /*
         * We can use the default sort for the filter if no 'sort' query string is set.
         * To enable this we need to add a 'defaultSort' method in the custom filter
         * or call the 'defaultSort' method on the filter. The 'defaultSort' fluent method
         * set value takes precedence to the sort value set using the custom filer.
         */
        if (! $this->request->exists('sort')) {
            if ($this->defaultSort !== null) {
                $queryParams['sort'] = $this->defaultSort;
            } elseif ($this->customFilter !== null && method_exists($this->customFilter, 'defaultSort')) {
                $queryParams['sort'] = $this->customFilter->defaultSort();
            }
        }

        return array_only($queryParams, $filters);
    }

    /**
     * Apply the sort filters.
     *
     * @param string|null $params
     */
    protected function filterSort($params = null)
    {
        if ($params === null || ! ($sortable = $this->model->sortable)) {
            return;
        }

        $sortable = array_wrap($sortable);

        foreach (explode(self::DELIMITER, $params) as $sortParam) {
            $column = ltrim($sortParam, '-');

            if (in_array($column, $sortable)) {
                $this->builder->orderBy($column, starts_with($sortParam, '-') ? 'desc' : 'asc');
            }
        }
    }

    /**
     * Apply the limit filter.
     *
     * @param int|string|null $limit
     */
    protected function filterLimit($limit = null)
    {
        $this->limit = $this->normalizeLimit($limit);
    }

    /**
     * Normalize the limit value.
     *
     * @param mixed $limit
     * @return int
     */
    protected function normalizeLimit($limit)
    {
        if ($limit !== null && filter_var($limit, FILTER_VALIDATE_INT) !== false) {
            return (int) min(max($limit, $this->minLimit), $this->maxLimit);
        }

        return $this->defaultLimit;
    }

    /**
     * Get the config value.
     *
     * @param string $key
     * @param mixed|null $default
     * @return mixed
     */
    protected function config($key, $default = null)
    {
        return data_get($this->config, $key, $default);
    }
}
