<?php

namespace App\Winds\Libraries\QueryFilter;

interface QueryFilterContract
{
    /**
     * Set the Query Builder.
     *
     * @param \Illuminate\Database\Eloquent\Builder $builder
     * @return $this
     */
    public function builder($builder);

    /**
     * Set the custom filter.
     *
     * @param \App\Winds\Libraries\QueryFilter\FilterContract|string $filter
     * @return $this
     * @throws \Exception
     */
    public function customFilter($filter);

    /**
     * Set the resource or resource collection to be used for data transformation.
     * Setting the resource enables the data transformation.
     *
     * @param \Illuminate\Http\Resources\Json\JsonResource|\Illuminate\Http\Resources\Json\ResourceCollection $resource
     * @return $this
     */
    public function transformWith($resource);

    /**
     * Set the default sort order if none are provided in the query string.
     *
     * @param string $sort
     * @return $this
     */
    public function defaultSort($sort);

    /**
     * Set the additional data to be added to the response.
     *
     * @param array $additional
     * @return $this
     */
    public function additionalData(array $additional);

    /**
     * Apply the filters and get the result.
     *
     * @param array $columns
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator|\Illuminate\Database\Eloquent\Collection|\Illuminate\Database\Eloquent\Model|\Illuminate\Http\Resources\Json\JsonResource|\Illuminate\Http\Resources\Json\ResourceCollection|null
     * @throws \Exception
     */
    public function get($columns = ['*']);

    /**
     * Apply the filters and paginate the result.
     *
     * @param array $columns
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator|\Illuminate\Http\Resources\Json\ResourceCollection|null
     * @throws \Exception
     */
    public function paginate($columns = ['*']);
}
