<?php

namespace App\Http\Middleware;

use Closure;

class CheckAccountStatus
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @param string|null $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        /** @var \App\Models\User $user */
        $user = $request->user($guard);

        if ($user && ! $user->active) {
            abort(403, 'Account blocked.');
        }

        return $next($request);
    }
}
